import { test, expect } from '@playwright/test';

// TELCOMPETIOION Root: manifest-portal.html auf http://localhost:9323/
const PORTAL_URL = '/manifest-portal.html';

test.describe('Manifest-Portal – Öffentliche Ansicht & Admin', () => {
  test('Portal ist erreichbar und zeigt Überschriften', async ({ page }) => {
    await page.goto(PORTAL_URL, { waitUntil: 'load', timeout: 30000 });
    await page.waitForLoadState('networkidle', { timeout: 10000 }).catch(() => {});
    await page.waitForTimeout(2000);

    // Warte auf h1 Element
    await page.waitForSelector('h1', { timeout: 10000 }).catch(() => {});

    // Prüfe H1 Titel (existiert in Zeile 89)
    const h1Elements = page.locator('h1').filter({ hasText: /Manifest of Thinkers.*Portal/i });
    const h1Count = await h1Elements.count();
    expect(h1Count).toBeGreaterThan(0);
    const firstH1 = h1Elements.first();
    const h1Visible = await firstH1.isVisible({ timeout: 5000 }).catch(() => false);
    expect(h1Visible).toBeTruthy();
    
    // Prüfe Subtitle
    const subtitle = page.getByText(/Öffentliche Ansicht.*nur lesen/i).first();
    const subtitleCount = await subtitle.count();
    expect(subtitleCount).toBeGreaterThan(0);
    const subtitleVisible = await subtitle.isVisible({ timeout: 5000 }).catch(() => false);
    expect(subtitleVisible).toBeTruthy();

    // Prüfe Zurück-Link
    const zurueckLink = page.getByRole('link', { name: /Zurück/i }).first();
    const zurueckCount = await zurueckLink.count();
    expect(zurueckCount).toBeGreaterThan(0);
    const zurueckVisible = await zurueckLink.isVisible({ timeout: 5000 }).catch(() => false);
    expect(zurueckVisible).toBeTruthy();
  });

  test('Bonus-Ökosystem, Module und Mesh-Historie sind sichtbar', async ({ page }) => {
    await page.goto(PORTAL_URL, { waitUntil: 'load', timeout: 30000 });
    await page.waitForLoadState('networkidle', { timeout: 10000 }).catch(() => {});
    await page.waitForTimeout(2000);

    // Scrolle zu Sidebar
    await page.evaluate(() => window.scrollTo(0, 0));
    await page.waitForTimeout(1000);

    // Prüfe Bonus-Button (id="bonusBtn" existiert in Zeile 130)
    const bonusBtn = page.locator('button#bonusBtn').first();
    const bonusCount = await bonusBtn.count();
    expect(bonusCount).toBeGreaterThan(0);
    const bonusVisible = await bonusBtn.isVisible({ timeout: 5000 }).catch(() => false);
    expect(bonusVisible).toBeTruthy();

    // Prüfe Module Button (id="modulesBtn" existiert in Zeile 136)
    const moduleBtn = page.locator('button#modulesBtn').first();
    const moduleCount = await moduleBtn.count();
    expect(moduleCount).toBeGreaterThan(0);
    const moduleVisible = await moduleBtn.isVisible({ timeout: 5000 }).catch(() => false);
    expect(moduleVisible).toBeTruthy();

    // Prüfe Mesh Button (id="meshHistoryBtn" existiert in Zeile 142)
    const meshBtn = page.locator('button#meshHistoryBtn').first();
    const meshCount = await meshBtn.count();
    expect(meshCount).toBeGreaterThan(0);
    const meshVisible = await meshBtn.isVisible({ timeout: 5000 }).catch(() => false);
    expect(meshVisible).toBeTruthy();
  });

  test('Verifizierung-Bereich ist vorhanden', async ({ page }) => {
    await page.goto(PORTAL_URL, { waitUntil: 'load', timeout: 30000 });
    await page.waitForLoadState('networkidle', { timeout: 10000 }).catch(() => {});
    await page.waitForTimeout(2000);

    // Prüfe Verifizierungs-Button (id="verifyBtn" existiert in Zeile 149)
    const verifyBtn = page.locator('button#verifyBtn').first();
    const verifyCount = await verifyBtn.count();
    expect(verifyCount).toBeGreaterThan(0);
    const verifyVisible = await verifyBtn.isVisible({ timeout: 5000 }).catch(() => false);
    expect(verifyVisible).toBeTruthy();
    
    // Prüfe Token-Input (kann verschiedene IDs haben)
    const tokenInput = page.locator('input#token').first();
    const tokenCount = await tokenInput.count();
    if (tokenCount === 0) {
      // Alternative: Suche nach Input mit placeholder="Token"
      const tokenInputAlt = page.getByPlaceholder(/Token/i).first();
      const tokenAltCount = await tokenInputAlt.count();
      expect(tokenAltCount).toBeGreaterThan(0);
    } else {
      const tokenVisible = await tokenInput.isVisible({ timeout: 5000 }).catch(() => false);
      expect(tokenVisible).toBeTruthy();
    }
  });

  test('Admin-Moderation-Controls sind vorhanden', async ({ page }) => {
    await page.goto(PORTAL_URL, { waitUntil: 'load', timeout: 30000 });
    await page.waitForLoadState('networkidle', { timeout: 10000 }).catch(() => {});
    await page.waitForTimeout(2000);

    // Scrolle zu Admin-Bereich
    await page.evaluate(() => window.scrollTo(0, document.body.scrollHeight));
    await page.waitForTimeout(1000);

    // Prüfe Admin-Buttons direkt (sollten existieren, auch wenn nicht sichtbar)
    const verbergenBtn = page.locator('button#modHideBtn').first();
    const sichtbarBtn = page.locator('button#modUnhideBtn').first();
    const statsBtn = page.locator('button#modStatsBtn').first();
    const selectBtn = page.locator('button#selectAllBtn').first();

    // Mindestens einer sollte existieren
    const verbergenCount = await verbergenBtn.count();
    const sichtbarCount = await sichtbarBtn.count();
    const statsCount = await statsBtn.count();
    const selectCount = await selectBtn.count();
    
    const anyExists = verbergenCount > 0 || sichtbarCount > 0 || statsCount > 0 || selectCount > 0;
    expect(anyExists).toBeTruthy();
    
    // Prüfe ob mindestens einer sichtbar ist
    const anyVisible = (verbergenCount > 0 && await verbergenBtn.isVisible({ timeout: 2000 }).catch(() => false)) ||
                      (sichtbarCount > 0 && await sichtbarBtn.isVisible({ timeout: 2000 }).catch(() => false)) ||
                      (statsCount > 0 && await statsBtn.isVisible({ timeout: 2000 }).catch(() => false)) ||
                      (selectCount > 0 && await selectBtn.isVisible({ timeout: 2000 }).catch(() => false));
    
    // Wenn keiner sichtbar ist, prüfe ob Admin-Bereich existiert
    if (!anyVisible) {
      const adminSection = page.locator('section, div').filter({ hasText: /Admin|Moderation/i }).first();
      const adminCount = await adminSection.count();
      expect(adminCount).toBeGreaterThan(0);
    }
  });

  test('Hidden Viewer, Medien & Chat & P2P Datei-Transfer – Smoke', async ({ page }) => {
    await page.goto(PORTAL_URL, { waitUntil: 'load', timeout: 30000 });
    await page.waitForLoadState('networkidle', { timeout: 10000 }).catch(() => {});
    await page.waitForTimeout(2000);

    // Scrolle durch die Seite
    await page.evaluate(() => window.scrollTo(0, document.body.scrollHeight / 2));
    await page.waitForTimeout(1000);

    // Prüfe Hidden Viewer Button (id="loadHiddenBtn" existiert in Zeile 185)
    const hiddenBtn = page.locator('button#loadHiddenBtn').first();
    const hiddenCount = await hiddenBtn.count();
    expect(hiddenCount).toBeGreaterThan(0);
    const hiddenVisible = await hiddenBtn.isVisible({ timeout: 3000 }).catch(() => false);
    expect(hiddenVisible).toBeTruthy();

    // Scrolle weiter zu Medien-Bereich
    await page.evaluate(() => window.scrollTo(0, document.body.scrollHeight * 0.6));
    await page.waitForTimeout(1000);

    // Prüfe Medien-Text oder Buttons (disabled buttons existieren in Zeilen 194-195)
    const mediaText = page.getByText(/Medien/i).first();
    const mediaStartBtn = page.locator('button#mediaStartBtn').first();
    const mediaTextCount = await mediaText.count();
    const mediaBtnCount = await mediaStartBtn.count();
    const mediaVisible = (mediaTextCount > 0 && await mediaText.isVisible({ timeout: 2000 }).catch(() => false)) ||
                         (mediaBtnCount > 0);
    
    if (mediaVisible) {
      // Scrolle zu P2P-Bereich
      await page.evaluate(() => window.scrollTo(0, document.body.scrollHeight));
      await page.waitForTimeout(1000);

      // P2P Datei-Input (id="p2pFile" existiert in Zeile 218)
      const p2pFileInput = page.locator('input#p2pFile[type="file"]').first();
      const p2pCount = await p2pFileInput.count();
      const p2pVisible = p2pCount > 0 && await p2pFileInput.isVisible({ timeout: 3000 }).catch(() => false);
      expect(p2pVisible).toBeTruthy();
    }
  });

  test('Daten laden & Live-Funktionen – Smoke', async ({ page }) => {
    await page.goto(PORTAL_URL, { waitUntil: 'load', timeout: 30000 });
    await page.waitForLoadState('networkidle', { timeout: 10000 }).catch(() => {});
    await page.waitForTimeout(2000);

    // Scrolle zu Daten-Bereich (#dataSection)
    await page.evaluate(() => {
      const dataSection = document.getElementById('dataSection');
      if (dataSection) dataSection.scrollIntoView({ behavior: 'smooth', block: 'center' });
    });
    await page.waitForTimeout(1000);

    // Prüfe Daten-Buttons
    const jsonBtn = page.locator('label[for="jsonFile"]').first();
    const apiBtn = page.getByRole('button', { name: /API|laden/i }).first();
    const feedBtn = page.getByRole('button', { name: /Feed|leeren/i }).first();
    
    const jsonCount = await jsonBtn.count();
    const apiCount = await apiBtn.count();
    const feedCount = await feedBtn.count();
    
    const anyDataBtnVisible = (jsonCount > 0 && await jsonBtn.isVisible({ timeout: 2000 }).catch(() => false)) ||
                              (apiCount > 0 && await apiBtn.isVisible({ timeout: 2000 }).catch(() => false)) ||
                              (feedCount > 0 && await feedBtn.isVisible({ timeout: 2000 }).catch(() => false));
    expect(anyDataBtnVisible).toBeTruthy();

    // Scrolle zu Live-Bereich
    await page.evaluate(() => window.scrollTo(0, document.body.scrollHeight));
    await page.waitForTimeout(1000);

    // Prüfe Live-Buttons (id="initLiveBtn" existiert in Zeile 268, ist disabled)
    const liveInitBtn = page.locator('button#initLiveBtn').first();
    const liveCount = await liveInitBtn.count();
    expect(liveCount).toBeGreaterThan(0);
    // Button existiert, auch wenn disabled
    const liveVisible = await liveInitBtn.isVisible({ timeout: 3000 }).catch(() => false);
    expect(liveVisible).toBeTruthy();
  });

  test('R2 Datei-Transfer-UI vorhanden', async ({ page }) => {
    await page.goto(PORTAL_URL, { waitUntil: 'load', timeout: 30000 });
    await page.waitForLoadState('networkidle', { timeout: 10000 }).catch(() => {});
    await page.waitForTimeout(2000);

    // Scrolle zu R2-Bereich
    await page.evaluate(() => window.scrollTo(0, document.body.scrollHeight));
    await page.waitForTimeout(1000);

    // Suche nach R2-Datei-Input (id="filePick" existiert in Zeile 283)
    const fileInput = page.locator('input#filePick[type="file"]').first();
    const fileCount = await fileInput.count();
    expect(fileCount).toBeGreaterThan(0);
    const fileInputVisible = await fileInput.isVisible({ timeout: 3000 }).catch(() => false);
    expect(fileInputVisible).toBeTruthy();
  });

  test('Verifizierungs-Button ist klickbar (Smoke)', async ({ page }) => {
    await page.goto(PORTAL_URL, { waitUntil: 'load', timeout: 30000 });
    await page.waitForLoadState('networkidle', { timeout: 10000 }).catch(() => {});
    await page.waitForTimeout(2000);

    const verifyButton = page.locator('button#verifyBtn').first();
    const verifyCount = await verifyButton.count();
    expect(verifyCount).toBeGreaterThan(0);
    const verifyVisible = await verifyButton.isVisible({ timeout: 5000 }).catch(() => false);
    expect(verifyVisible).toBeTruthy();
    
    // Prüfe ob disabled
    const isDisabled = await verifyButton.getAttribute('disabled');
    if (!isDisabled) {
      await verifyButton.click({ timeout: 5000 });
      await page.waitForTimeout(1000);
    }

    // Portal sollte weiterhin funktionsfähig bleiben (H1 sollte noch sichtbar sein)
    const h1 = page.locator('h1').first();
    const h1Count = await h1.count();
    expect(h1Count).toBeGreaterThan(0);
  });

  test('Medien & Chat: Nachricht eingeben und Senden klicken', async ({ page }) => {
    await page.goto(PORTAL_URL, { waitUntil: 'load', timeout: 30000 });
    await page.waitForLoadState('networkidle', { timeout: 10000 }).catch(() => {});
    await page.waitForTimeout(2000);

    // Scrolle zu Medien-Bereich
    await page.evaluate(() => {
      const mediaSection = Array.from(document.querySelectorAll('h3, h4')).find(el => 
        el.textContent?.includes('Medien') || el.textContent?.includes('Chat')
      );
      if (mediaSection) mediaSection.scrollIntoView({ behavior: 'smooth', block: 'center' });
    });
    await page.waitForTimeout(1000);

    // Suche nach Chat-Input (id="chatInput" existiert in Zeile 209, ist disabled)
    const chatInput = page.locator('input#chatInput').first();
    const chatCount = await chatInput.count();
    const chatInputVisible = chatCount > 0 && await chatInput.isVisible({ timeout: 3000 }).catch(() => false);
    
    if (chatInputVisible) {
      // Prüfe ob disabled
      const isDisabled = await chatInput.getAttribute('disabled');
      if (!isDisabled) {
        await chatInput.fill('Automatische Test-Nachricht');
        await page.waitForTimeout(500);

        const sendButton = page.locator('button#chatSendBtn').first();
        const sendCount = await sendButton.count();
        const sendVisible = sendCount > 0 && await sendButton.isVisible({ timeout: 3000 }).catch(() => false);
        if (sendVisible) {
          const sendDisabled = await sendButton.getAttribute('disabled');
          if (!sendDisabled) {
            await sendButton.click({ timeout: 5000 });
            await page.waitForTimeout(1000);
          }
        }
      }
    }

    // Portal sollte weiterhin sichtbar sein (H1 prüfen)
    const h1 = page.locator('h1').first();
    const h1Count = await h1.count();
    expect(h1Count).toBeGreaterThan(0);
  });

  test('Medien & Chat: Video/Audio-Steuerung klickbar', async ({ page }) => {
    await page.goto(PORTAL_URL, { waitUntil: 'load', timeout: 30000 });
    await page.waitForLoadState('networkidle', { timeout: 10000 }).catch(() => {});
    await page.waitForTimeout(2000);

    const startButton = page.locator('button#mediaStartBtn').first();
    const stopButton = page.locator('button#mediaStopBtn').first();

    // Prüfe ob Buttons existieren (sind disabled in Zeile 194-195)
    const startCount = await startButton.count();
    const stopCount = await stopButton.count();
    expect(startCount).toBeGreaterThan(0);
    expect(stopCount).toBeGreaterThan(0);

    // Nur testen wenn Buttons nicht disabled sind
    const startDisabled = await startButton.getAttribute('disabled');
    if (!startDisabled) {
      await startButton.click({ timeout: 5000 });
      await page.waitForTimeout(2000);

      const stopDisabled = await stopButton.getAttribute('disabled');
      if (!stopDisabled) {
        await stopButton.click({ timeout: 5000 });
        await page.waitForTimeout(1000);
      }
    }

    // Seite sollte weiter funktionsfähig sein (H1 prüfen)
    const h1 = page.locator('h1').first();
    const h1Count = await h1.count();
    expect(h1Count).toBeGreaterThan(0);
  });

  test('P2P Datei-Transfer: Dummy-Datei anhängen (wenn möglich)', async ({ page }, testInfo) => {
    await page.goto(PORTAL_URL, { waitUntil: 'load', timeout: 30000 });
    await page.waitForLoadState('networkidle', { timeout: 10000 }).catch(() => {});
    await page.waitForTimeout(2000);

    // Scrolle zu P2P-Bereich
    await page.evaluate(() => window.scrollTo(0, document.body.scrollHeight));
    await page.waitForTimeout(1000);

    // P2P-Dateifeld (id="p2pFile" existiert in Zeile 218)
    const fileInput = page.locator('input#p2pFile[type="file"]').first();
    const fileCount = await fileInput.count();
    
    const inputVisible = fileCount > 0 && await fileInput.isVisible({ timeout: 3000 }).catch(() => false);
    if (inputVisible) {
      try {
        await fileInput.setInputFiles({
          name: 'dummy.txt',
          mimeType: 'text/plain',
          buffer: Buffer.from('P2P-Testdatei'),
        }, { timeout: 5000 });
        await page.waitForTimeout(500);
      } catch (e) {
        testInfo.annotations.push({
          type: 'info',
          description: `P2P-Dateifeld gefunden aber Upload fehlgeschlagen: ${e}`,
        });
      }
    } else {
      testInfo.annotations.push({
        type: 'info',
        description: 'P2P-Dateifeld nicht gefunden oder nicht sichtbar.',
      });
    }

    // Prüfe Send-Button (id="p2pSendBtn" kann existieren, ist disabled)
    const sendButton = page.locator('button#p2pSendBtn').first();
    const sendCount = await sendButton.count();
    const sendVisible = sendCount > 0 && await sendButton.isVisible({ timeout: 3000 }).catch(() => false);
    if (sendVisible) {
      const sendDisabled = await sendButton.getAttribute('disabled');
      if (!sendDisabled) {
        await sendButton.click({ timeout: 5000 });
        await page.waitForTimeout(1000);
      }
    }

    // Portal sollte weiterhin sichtbar sein (H1 prüfen)
    const h1 = page.locator('h1').first();
    const h1Count = await h1.count();
    expect(h1Count).toBeGreaterThan(0);
  });

  test('Live-Funktionen: Raum betreten und Einladungslink kopieren', async ({ page }) => {
    await page.goto(PORTAL_URL, { waitUntil: 'load', timeout: 30000 });
    await page.waitForLoadState('networkidle', { timeout: 10000 }).catch(() => {});
    await page.waitForTimeout(2000);

    // Scrolle zu Live-Bereich
    await page.evaluate(() => window.scrollTo(0, document.body.scrollHeight));
    await page.waitForTimeout(1000);

    // Prüfe Init-Button (id="initLiveBtn" existiert in Zeile 268, ist disabled)
    const initButton = page.locator('button#initLiveBtn').first();
    const initCount = await initButton.count();
    expect(initCount).toBeGreaterThan(0);
    
    const initVisible = await initButton.isVisible({ timeout: 3000 }).catch(() => false);
    if (initVisible) {
      const initDisabled = await initButton.getAttribute('disabled');
      if (!initDisabled) {
        await initButton.click({ timeout: 5000 });
        await page.waitForTimeout(2000);
      }
    }

    // Prüfe Enter-Button
    const enterButton = page.getByRole('button', { name: /Raum|betreten/i }).first();
    const enterCount = await enterButton.count();
    if (enterCount > 0) {
      const enterVisible = await enterButton.isVisible({ timeout: 3000 }).catch(() => false);
      if (enterVisible) {
        const enterDisabled = await enterButton.getAttribute('disabled');
        if (!enterDisabled) {
          await enterButton.click({ timeout: 5000 });
          await page.waitForTimeout(1000);
        }
      }
    }

    // Prüfe Invite-Button
    const inviteButton = page.getByRole('button', { name: /Einladung|kopieren/i }).first();
    const inviteCount = await inviteButton.count();
    if (inviteCount > 0) {
      const inviteVisible = await inviteButton.isVisible({ timeout: 3000 }).catch(() => false);
      if (inviteVisible) {
        const inviteDisabled = await inviteButton.getAttribute('disabled');
        if (!inviteDisabled) {
          await inviteButton.click({ timeout: 5000 });
          await page.waitForTimeout(1000);
        }
      }
    }

    // Portal sollte weiterhin sichtbar sein (H1 prüfen)
    const h1 = page.locator('h1').first();
    const h1Count = await h1.count();
    expect(h1Count).toBeGreaterThan(0);
  });

  test('R2 Datei-Transfer: Dummy-Datei für Multipart-Upload setzen (wenn möglich)', async ({ page }, testInfo) => {
    await page.goto(PORTAL_URL, { waitUntil: 'load', timeout: 30000 });
    await page.waitForLoadState('networkidle', { timeout: 10000 }).catch(() => {});
    await page.waitForTimeout(2000);

    // Scrolle zu R2-Bereich
    await page.evaluate(() => window.scrollTo(0, document.body.scrollHeight));
    await page.waitForTimeout(1000);

    // R2-Datei-Input (id="filePick" existiert in Zeile 283)
    const fileInput = page.locator('input#filePick[type="file"]').first();
    const fileCount = await fileInput.count();
    
    const inputVisible = fileCount > 0 && await fileInput.isVisible({ timeout: 3000 }).catch(() => false);
    if (inputVisible) {
      try {
        await fileInput.setInputFiles({
          name: 'r2-dummy.txt',
          mimeType: 'text/plain',
          buffer: Buffer.from('R2-Testdatei'),
        }, { timeout: 5000 });
        await page.waitForTimeout(500);
      } catch (e) {
        testInfo.annotations.push({
          type: 'info',
          description: `R2-Dateifeld gefunden aber Upload fehlgeschlagen: ${e}`,
        });
      }
    } else {
      testInfo.annotations.push({
        type: 'info',
        description: 'R2-Dateifeld nicht gefunden oder nicht sichtbar.',
      });
    }

    // Prüfe Upload-Button (id="uploadBtn" existiert in Zeile 284, ist disabled)
    const uploadButton = page.getByRole('button', { name: /Hochladen|Multipart/i }).first();
    const uploadCount = await uploadButton.count();
    const uploadVisible = uploadCount > 0 && await uploadButton.isVisible({ timeout: 3000 }).catch(() => false);
    if (uploadVisible) {
      const uploadDisabled = await uploadButton.getAttribute('disabled');
      if (!uploadDisabled) {
        await uploadButton.click({ timeout: 5000 });
        await page.waitForTimeout(1000);
      }
    }

    // Portal sollte weiterhin sichtbar sein (H1 prüfen)
    const h1 = page.locator('h1').first();
    const h1Count = await h1.count();
    expect(h1Count).toBeGreaterThan(0);
  });
});
