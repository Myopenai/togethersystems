// Cloudflare Pages Function for TPGA Telbank transfer ledger
// Route: /api/telbank/transfers
//
// NOTE:
// - This implementation keeps transfers in an in-memory array per worker instance.
// - For production, you should attach a durable storage (e.g. D1, KV) and replace
//   the in-memory store with real persistence.

const memoryStore = [];

function makeId(prefix = 'tx') {
  return `${prefix}-${Date.now().toString(36)}-${Math.random()
    .toString(36)
    .slice(2, 8)}`;
}

function jsonResponse(status, body) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { 'Content-Type': 'application/json; charset=utf-8' },
  });
}

export async function onRequestGet(context) {
  const url = new URL(context.request.url);
  const walletAddress = url.searchParams.get('walletAddress');
  const direction = url.searchParams.get('direction');

  const items = memoryStore.filter((tr) => {
    if (walletAddress && tr.walletAddress && tr.walletAddress !== walletAddress) {
      return false;
    }
    if (direction && tr.direction !== direction) {
      return false;
    }
    return true;
  });

  // Newest first
  items.sort((a, b) => (a.createdAt < b.createdAt ? 1 : -1));

  return jsonResponse(200, { ok: true, items });
}

export async function onRequestPost(context) {
  const { request } = context;

  let payload;
  try {
    payload = await request.json();
  } catch {
    return jsonResponse(400, { ok: false, error: 'Invalid JSON body' });
  }

  const {
    direction,
    label,
    walletAddress,
    network,
    cryptoAmount,
    cryptoSymbol,
    fiatAmount,
    fiatCurrency,
    externalAccount,
    meta,
  } = payload || {};

  if (!direction || (direction !== 'in' && direction !== 'out')) {
    return jsonResponse(400, { ok: false, error: 'Invalid direction' });
  }

  if (
    typeof cryptoAmount !== 'number' ||
    !cryptoSymbol ||
    typeof fiatAmount !== 'number' ||
    !fiatCurrency
  ) {
    return jsonResponse(400, {
      ok: false,
      error:
        'cryptoAmount, cryptoSymbol, fiatAmount and fiatCurrency are required as numbers/strings',
    });
  }

  const id = makeId(direction === 'in' ? 'in' : 'out');
  const now = new Date().toISOString();

  const entry = {
    id,
    direction,
    label: label || (direction === 'in' ? 'Fiat→Crypto inflow' : 'Crypto→Fiat outflow'),
    walletAddress: walletAddress || null,
    network: network || null,
    cryptoAmount,
    cryptoSymbol,
    fiatAmount,
    fiatCurrency,
    externalAccount: externalAccount || null,
    meta: meta || {},
    status: 'logged',
    createdAt: now,
    updatedAt: now,
  };

  memoryStore.push(entry);

  return jsonResponse(200, { ok: true, transfer: entry });
}


