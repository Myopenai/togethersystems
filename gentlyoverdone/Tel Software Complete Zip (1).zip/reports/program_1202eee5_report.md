# Program Analysis Report - 1202eee5

**Original File:** Cms System Htm.htm
**Source URL:** https://tel1.jouwweb.nl/_downloads/c29fecc01041cdfbfc1ea3b34a34ddd1
**File Size:** 246508 bytes
**Content Type:** text/html; charset=UTF-8

## File Analysis

### Cms System Htm.htm
- **Type:** html
- **Size:** 246508 bytes
- **Extension:** .htm
- **title:** Advanced Builder - Vollständig Funktional
- **headings:** ['🚀 Schnell-Komponenten', '📝 Grundlegende Komponenten\n                    ℹ️ Info', '🔄 MODX Extras & Add-ons', '⚡ Erweiterte Widgets', '🚀 Enterprise Features', '📋 MODX Templates', '⚙️ MODX System Settings', '🌐 Website-Einstellungen', '🔒 Sicherheit', '📧 E-Mail-Einstellungen', '🔍 SEO & Analytics', '🌐 Erweiterte Einstellungen', '🖼️ Bild hochladen', '✏️ Komponente bearbeiten']
- **links:** [{'text': 'ℹ️ Info', 'href': 'javascript:void(0)'}]
- **images:** []
- **scripts:** []
- **forms:** 0
- **content_length:** 245052

### metadata.json
- **Type:** json
- **Size:** 81 bytes
- **Extension:** .json
- **error:** name 'v' is not defined

