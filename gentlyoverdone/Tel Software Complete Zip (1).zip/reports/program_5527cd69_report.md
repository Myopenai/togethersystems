# Program Analysis Report - 5527cd69

**Original File:** Tel Geschenk Package All Languages With Cover Zip.zip
**Source URL:** https://tel1.jouwweb.nl/_downloads/cdf7ef34db189368dbfe81dafffe2078
**File Size:** 50472 bytes
**Content Type:** application/zip

## File Analysis

### TEL_Cadeau_NL_final.html
- **Type:** html
- **Size:** 3792 bytes
- **Extension:** .html
- **title:** -
- **headings:** []
- **links:** []
- **images:** []
- **scripts:** []
- **forms:** 0
- **content_length:** 3773

### TEL_Cadeau_NL_final.md
- **Type:** text
- **Size:** 442 bytes
- **Extension:** .md
- **content_length:** 427
- **lines:** 12
- **words:** 37
- **preview:** 📜 Nederlandse Versie (gecorrigeerd & vertaald)

\[Volledige, grammaticaal gecorrigeerde tekst Deel 1--5, zoals hierboven
uitgewerkt\]

------------------------------------------------------------------------

Links en Referenties: - 🔗 https://tel1.jouwweb.nl/servicesoftware - 🔗
https://chatgpt.com/share/68b89c90-27e0-8005-8f16-2d157a2d1ce0 (chatlink
als fanartikel) - 📧 gentlyoverdone@outlook.com - 🌍 DEV-TEL Forum --
Welkom


### TEL_Cadeau_NL_final.odt
- **Type:** unknown
- **Size:** 9232 bytes
- **Extension:** .odt

### TEL_Cadeau_NL_final.pdf
- **Type:** unknown
- **Size:** 1963 bytes
- **Extension:** .pdf

### TEL_Geschenk_Cover.pdf
- **Type:** unknown
- **Size:** 2632 bytes
- **Extension:** .pdf

### TEL_Geschenk_DE_final.html
- **Type:** html
- **Size:** 3793 bytes
- **Extension:** .html
- **title:** -
- **headings:** []
- **links:** []
- **images:** []
- **scripts:** []
- **forms:** 0
- **content_length:** 3771

### TEL_Geschenk_DE_final.md
- **Type:** text
- **Size:** 446 bytes
- **Extension:** .md
- **content_length:** 430
- **lines:** 12
- **words:** 38
- **preview:** 📜 Deutsche Version (korrigiert) -- Vollständiger Text

\[Grammatisch korrigierter deutscher Text Teil 1--5, wie oben
ausgearbeitet\]

------------------------------------------------------------------------

Links und Referenzen: - 🔗 https://tel1.jouwweb.nl/servicesoftware - 🔗
https://chatgpt.com/share/68b89c90-27e0-8005-8f16-2d157a2d1ce0 (Chatlink
als Fanartikel) - 📧 gentlyoverdone@outlook.com - 🌍 DEV-TEL Forum --
Willkommen


### TEL_Geschenk_DE_final.odt
- **Type:** unknown
- **Size:** 9232 bytes
- **Extension:** .odt

### TEL_Geschenk_DE_final.pdf
- **Type:** unknown
- **Size:** 1966 bytes
- **Extension:** .pdf

### TEL_Gift_EN_final.html
- **Type:** html
- **Size:** 3776 bytes
- **Extension:** .html
- **title:** -
- **headings:** []
- **links:** []
- **images:** []
- **scripts:** []
- **forms:** 0
- **content_length:** 3757

### TEL_Gift_EN_final.md
- **Type:** text
- **Size:** 426 bytes
- **Extension:** .md
- **content_length:** 411
- **lines:** 11
- **words:** 41
- **preview:** 📜 English Version (corrected & translated)

\[Corrected and complete English text Parts 1--5, as worked out above\]

------------------------------------------------------------------------

Links and References: - 🔗 https://tel1.jouwweb.nl/servicesoftware - 🔗
https://chatgpt.com/share/68b89c90-27e0-8005-8f16-2d157a2d1ce0 (chat
link as fan article) - 📧 gentlyoverdone@outlook.com - 🌍 DEV-TEL Forum
-- Welcome


### TEL_Gift_EN_final.odt
- **Type:** unknown
- **Size:** 9213 bytes
- **Extension:** .odt

### TEL_Gift_EN_final.pdf
- **Type:** unknown
- **Size:** 1953 bytes
- **Extension:** .pdf

