# Program Analysis Report - ca2ffef0

**Original File:** schermafbeelding-2025-10-12-164500-high.png
**Source URL:** https://primary.jwwb.nl/public/h/o/b/temp-nyratlbjkkriqxftlyfy/schermafbeelding-2025-10-12-164500-high.png
**File Size:** 107242 bytes
**Content Type:** image/png

## File Analysis

### metadata.json
- **Type:** json
- **Size:** 104 bytes
- **Extension:** .json
- **error:** name 'v' is not defined

### schermafbeelding-2025-10-12-164500-high.png
- **Type:** unknown
- **Size:** 107242 bytes
- **Extension:** .png

