# Program Analysis Report - 1ee73275

**Original File:** Schuldenvrij.zip
**Source URL:** https://tel1.jouwweb.nl/_downloads/31af6a83e01ec58eaaeb0c2048eb27a9
**File Size:** 480931 bytes
**Content Type:** application/zip

## File Analysis

### Brief 2.Aanpassen beslagvrije voet
- **Type:** unknown
- **Size:** 389 bytes
- **Extension:** .aanpassen beslagvrije voet

### Nibud-voorbeeldbrief-1-Inventarisatie-schulden.docx
- **Type:** unknown
- **Size:** 62059 bytes
- **Extension:** .docx

### Nibud-voorbeeldbrief-2-Aanpassen-beslagvrije-voet.docx
- **Type:** unknown
- **Size:** 63727 bytes
- **Extension:** .docx

### Nibud-voorbeeldbrief-3-Wijziging-aflossingsruimte.docx
- **Type:** unknown
- **Size:** 61666 bytes
- **Extension:** .docx

### Nibud-voorbeeldbrief-4-Bevriezing-vordering-van-schuldeisers.docx
- **Type:** unknown
- **Size:** 61968 bytes
- **Extension:** .docx

### Nibud-voorbeeldbrief-5-Verlaging-aflossing.docx
- **Type:** unknown
- **Size:** 61755 bytes
- **Extension:** .docx

### Nibud-voorbeeldbrief-6-Verhoging-aflossing.docx
- **Type:** unknown
- **Size:** 61701 bytes
- **Extension:** .docx

### Nibud-voorbeeldbrief-7-Voorstel-schuldeisers.docx
- **Type:** unknown
- **Size:** 61949 bytes
- **Extension:** .docx

### Nibud-voorbeeldbrief-8-Bevriezing-vordering-bij-loonbeslag.docx
- **Type:** unknown
- **Size:** 61743 bytes
- **Extension:** .docx

### Nibud-voorbeeldbrief-9-Verzoek-om-uitstel-van-betaling.docx
- **Type:** unknown
- **Size:** 64580 bytes
- **Extension:** .docx

