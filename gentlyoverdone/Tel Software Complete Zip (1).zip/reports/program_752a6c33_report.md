# Program Analysis Report - 752a6c33

**Original File:** schermafbeelding-2025-09-02-030304-high.png
**Source URL:** https://primary.jwwb.nl/public/h/o/b/temp-nyratlbjkkriqxftlyfy/schermafbeelding-2025-09-02-030304-high.png
**File Size:** 239383 bytes
**Content Type:** image/png

## File Analysis

### metadata.json
- **Type:** json
- **Size:** 104 bytes
- **Extension:** .json
- **error:** name 'v' is not defined

### schermafbeelding-2025-09-02-030304-high.png
- **Type:** unknown
- **Size:** 239383 bytes
- **Extension:** .png

