# Program Analysis Report - b2fadea4

**Original File:** Musical Education Program Html.html
**Source URL:** https://tel1.jouwweb.nl/_downloads/6d931107b710e91c62770301f8940def
**File Size:** 30116 bytes
**Content Type:** text/html; charset=UTF-8

## File Analysis

### metadata.json
- **Type:** json
- **Size:** 97 bytes
- **Extension:** .json
- **error:** name 'v' is not defined

### Musical Education Program Html.html
- **Type:** html
- **Size:** 30116 bytes
- **Extension:** .html
- **title:** Musical Education Program - Professionelles Musiklernsystem
- **headings:** ['🎵 Musical Education Program', '🎼 Musiklektionen', 'Grundlagen der Musiktheorie', 'Notenlesen', 'Rhythmus und Takt', 'Harmonielehre', 'Gehörbildung', 'Komposition', '🎹 Interaktives Klavier', 'Gespielte Note', '📚 Musiktheorie', 'Grundlagen der Musik', 'Das Notensystem', 'Tonleitern', 'Akkorde', 'Rhythmus und Takt', '🎯 Übungen']
- **links:** []
- **images:** []
- **scripts:** []
- **forms:** 0
- **content_length:** 29243

