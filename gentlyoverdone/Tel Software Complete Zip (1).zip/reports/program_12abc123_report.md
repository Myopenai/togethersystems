# Program Analysis Report - 12abc123

**Original File:** index.html
**Source URL:** http://www.hahn-borkum.de/index.html
**File Size:** 1870 bytes
**Content Type:** text/html

## File Analysis

### index.html
- **Type:** html
- **Size:** 1870 bytes
- **Extension:** .html
- **title:** Borkum grüsst den Rest der Welt !
- **headings:** ['Achtung!']
- **links:** [{'text': 'Netscape', 'href': 'http://www.netscape.com'}, {'text': 'MS Internet Explorer', 'href': 'http://www.microsoft.de'}]
- **images:** []
- **scripts:** []
- **forms:** 0
- **content_length:** 1866

### metadata.json
- **Type:** json
- **Size:** 71 bytes
- **Extension:** .json
- **error:** name 'v' is not defined

