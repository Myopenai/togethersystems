# Program Analysis Report - 97ee7a41

**Original File:** Relax Html.html
**Source URL:** https://tel1.jouwweb.nl/_downloads/b0a82cd0dec55849bc63c0218a0f55fc
**File Size:** 13620 bytes
**Content Type:** text/html; charset=UTF-8

## File Analysis

### metadata.json
- **Type:** json
- **Size:** 77 bytes
- **Extension:** .json
- **error:** name 'v' is not defined

### Relax Html.html
- **Type:** html
- **Size:** 13620 bytes
- **Extension:** .html
- **title:** Singular: Alles in einer Datei
- **headings:** ['Singular']
- **links:** [{'text': 'gentlyoverdone@outlook.com', 'href': 'mailto:gentlyoverdone@outlook.com'}, {'text': '+31 6 1380 3782', 'href': 'tel:+31613803782'}, {'text': 'www.tel1.nl', 'href': 'https://tel1.jouwweb.nl/-2'}, {'text': 'https://tel1.jouwweb.nl/-2', 'href': 'https://tel1.jouwweb.nl/-2'}, {'text': 'https://www.gofundme.com/f/magnitudo?utm_campaign=unknown&utm_medium=referral&utm_source=widget', 'href': 'https://www.gofundme.com/f/magnitudo?utm_campaign=unknown&utm_medium=referral&utm_source=widget'}, {'text': 'Jetzt spenden via GoFundMe', 'href': 'https://www.gofundme.com/f/magnitudo?utm_campaign=unknown&utm_medium=referral&utm_source=widget'}]
- **images:** []
- **scripts:** []
- **forms:** 0
- **content_length:** 13539

