# Program Analysis Report - d07cfe46

**Original File:** schermafbeelding-2025-08-22-154610-high.png
**Source URL:** https://primary.jwwb.nl/public/h/o/b/temp-nyratlbjkkriqxftlyfy/schermafbeelding-2025-08-22-154610-high.png
**File Size:** 126871 bytes
**Content Type:** image/png

## File Analysis

### metadata.json
- **Type:** json
- **Size:** 104 bytes
- **Extension:** .json
- **error:** name 'v' is not defined

### schermafbeelding-2025-08-22-154610-high.png
- **Type:** unknown
- **Size:** 126871 bytes
- **Extension:** .png

