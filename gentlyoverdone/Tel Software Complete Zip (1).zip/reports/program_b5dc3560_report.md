# Program Analysis Report - b5dc3560

**Original File:** schermafbeelding-2025-10-13-202917-high.png
**Source URL:** https://primary.jwwb.nl/public/h/o/b/temp-nyratlbjkkriqxftlyfy/schermafbeelding-2025-10-13-202917-high.png
**File Size:** 249763 bytes
**Content Type:** image/png

## File Analysis

### metadata.json
- **Type:** json
- **Size:** 104 bytes
- **Extension:** .json
- **error:** name 'v' is not defined

### schermafbeelding-2025-10-13-202917-high.png
- **Type:** unknown
- **Size:** 249763 bytes
- **Extension:** .png

