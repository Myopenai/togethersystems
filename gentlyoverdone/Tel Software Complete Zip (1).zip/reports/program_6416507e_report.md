# Program Analysis Report - 6416507e

**Original File:** tel1nl.html
**Source URL:** https://bunqbank.w3spaces.com/tel1nl.html
**File Size:** 55947 bytes
**Content Type:** text/html

## File Analysis

### metadata.json
- **Type:** json
- **Size:** 73 bytes
- **Extension:** .json
- **error:** name 'v' is not defined

### tel1nl.html
- **Type:** html
- **Size:** 55947 bytes
- **Extension:** .html
- **title:** Create your own website | W3 Spaces
- **headings:** ['Notice: This Site is User-Created']
- **links:** [{'text': 'Start building today!', 'href': 'https://www.w3schools.com/spaces/index.php'}, {'text': 'report it here', 'href': 'mailto:hello@w3schools.com'}, {'text': 'Continue', 'href': '#'}]
- **images:** []
- **scripts:** []
- **forms:** 0
- **content_length:** 55947

