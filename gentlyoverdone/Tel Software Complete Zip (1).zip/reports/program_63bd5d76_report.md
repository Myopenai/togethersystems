# Program Analysis Report - 63bd5d76

**Original File:** Cursor Sftp One Prompt Pack Zip.zip
**Source URL:** https://tel1.jouwweb.nl/_downloads/1060778f7516513ec020b0640b3561d1
**File Size:** 3455 bytes
**Content Type:** application/zip

## File Analysis

### README.md
- **Type:** text
- **Size:** 537 bytes
- **Extension:** .md
- **content_length:** 508
- **lines:** 14
- **words:** 68
- **preview:** # Cursor SFTP One‑Prompt Pack
Ziel: **Ein Prompt** in Cursor („deploy jetzt“) triggert ein **vollautomatisches SFTP‑Deploy**.
## Setup
1) `cd mcp-sftp && npm i`
2) `.env.example` → `.env` mit SFTP‑Zugang füllen
3) `.cursor/mcp.json` ins Projekt kopieren (falls vorhanden: mergen)

## Nutzung
Im Cursor‑Chat: **deploy jetzt** – Cursor ruft Tool `deploy_default` (MCP `sftp`) auf.
Weitere Prompts: „list /var/www/html“, „sync ./dist → /var/www/html“.

## Sicherheit
SSH‑Key bevorzugen; `.env` nicht com...

### mcp.json
- **Type:** json
- **Size:** 681 bytes
- **Extension:** .json
- **error:** name 'v' is not defined

### .env.example
- **Type:** unknown
- **Size:** 227 bytes
- **Extension:** .example

### package.json
- **Type:** json
- **Size:** 255 bytes
- **Extension:** .json
- **error:** name 'v' is not defined

### server.mjs
- **Type:** unknown
- **Size:** 4982 bytes
- **Extension:** .mjs

