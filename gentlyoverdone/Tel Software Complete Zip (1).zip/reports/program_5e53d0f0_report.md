# Program Analysis Report - 5e53d0f0

**Original File:** schermafbeelding-2025-10-13-133756-high.png
**Source URL:** https://primary.jwwb.nl/public/h/o/b/temp-nyratlbjkkriqxftlyfy/schermafbeelding-2025-10-13-133756-high.png
**File Size:** 508193 bytes
**Content Type:** image/png

## File Analysis

### metadata.json
- **Type:** json
- **Size:** 104 bytes
- **Extension:** .json
- **error:** name 'v' is not defined

### schermafbeelding-2025-10-13-133756-high.png
- **Type:** unknown
- **Size:** 508193 bytes
- **Extension:** .png

