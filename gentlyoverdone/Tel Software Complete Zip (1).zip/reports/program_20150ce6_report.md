# Program Analysis Report - 20150ce6

**Original File:** University Html.html
**Source URL:** https://tel1.jouwweb.nl/_downloads/e3ed238e00de74872dd56fb9a0945cdc
**File Size:** 78257 bytes
**Content Type:** text/html; charset=UTF-8

## File Analysis

### metadata.json
- **Type:** json
- **Size:** 82 bytes
- **Extension:** .json
- **error:** name 'v' is not defined

### University Html.html
- **Type:** html
- **Size:** 78257 bytes
- **Extension:** .html
- **title:** PSY-TEL System - Psychology Enhanced Telecommunications
- **headings:** ['🧠 PSY-TEL SYSTEM', '🎯\n                PSY-TEL System Overview', 'What is PSY-TEL Logic?', '🧠 PSYCHOLOGY', '📡 TELECOMMUNICATIONS', '🔍 LOGIC', '🎓 University Validated Principles', '🧠\n                Psychology Analysis Engine', '📡\n                Telecommunications Hub', 'Connection Status', 'Quality Metrics', '🤖\n                AI Logic Engine', '🎓\n                University Validation System', '🎨\n                Real-World PSY-TEL Applications', '🏥 Healthcare Communication', '🎓 Educational Platforms', '💼 Business Communications', '🎮 Gaming & Entertainment', '🔗\n                System Integration & APIs', '🌐 Web APIs', '📱 Mobile SDKs', '🔌 WebRTC Integration', '📊\n                System Status Dashboard', '🧠 Psychology Engine', '📡 Telcom Hub', '🤖 AI Logic', '🎓 Validation', '📚\n                Documentation & Resources', '📖 Quick Start Guide', '🎓 University Research', '🔧 Developer API', '🎨 Design Guidelines']
- **links:** [{'text': 'View Quick Start →', 'href': '#'}, {'text': 'View Research →', 'href': '#'}, {'text': 'View API Docs →', 'href': '#'}, {'text': 'View Guidelines →', 'href': '#'}]
- **images:** []
- **scripts:** []
- **forms:** 0
- **content_length:** 77475

