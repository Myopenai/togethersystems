# Program Analysis Report - d10b7f46

**Original File:** noten-high.jpg
**Source URL:** https://primary.jwwb.nl/public/h/o/b/temp-nyratlbjkkriqxftlyfy/noten-high.jpg
**File Size:** 100783 bytes
**Content Type:** image/jpeg

## File Analysis

### metadata.json
- **Type:** json
- **Size:** 75 bytes
- **Extension:** .json
- **error:** name 'v' is not defined

### noten-high.jpg
- **Type:** unknown
- **Size:** 100783 bytes
- **Extension:** .jpg

