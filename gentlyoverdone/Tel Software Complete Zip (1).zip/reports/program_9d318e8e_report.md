# Program Analysis Report - 9d318e8e

**Original File:** Globale Meeting Uhr Onefile V 2 Html.html
**Source URL:** https://tel1.jouwweb.nl/_downloads/c1f56b3bf6528f5516a8af5857d09dd3
**File Size:** 147560 bytes
**Content Type:** text/html; charset=UTF-8

## File Analysis

### Globale Meeting Uhr Onefile V 2 Html.html
- **Type:** html
- **Size:** 147560 bytes
- **Extension:** .html
- **title:** Globale Meeting-Uhr – One-File App (v2)
- **headings:** ['Globale Meeting-Uhr UTC · Lokal · Partner', '🕐 Aktuelle Zeiten weltweit', '1) Eingabe', '2) Ergebnis', '🌍 Globale Verabredungs-Finder', 'Team-Zeitzonen', 'Ruhezeiten-Verhandler', '🚀 Follow-the-Sun Task Router', 'Team-Verteilung', 'Jetlag-Coach', '📅 Kultur-/Feiertags-Harmonizer', 'Feiertage & Kultur', 'Daylight-Planner', '🌐 Erweiterte Zeitzonen-Features', 'Bandbreiten-/Latenz-Map', 'Zeitzonen-To-Do', '🎯 Meeting-Alias-Links & Fairness-Score', 'Meeting-Link Generator', 'Fairness-Score', 'Anleitung (kinderleicht)', 'Producer / Kontakt']
- **links:** [{'text': 'App', 'href': '#app'}, {'text': 'Anleitung', 'href': '#how'}, {'text': 'Producer', 'href': '#producer'}, {'text': 'gentlyoverdone@outlook.com', 'href': 'mailto:gentlyoverdone@outlook.com'}, {'text': 'www.tel1.nl', 'href': 'https://tel1.jouwweb.nl/contact'}, {'text': 'https://tel1.jouwweb.nl/contact', 'href': 'https://tel1.jouwweb.nl/contact'}, {'text': 'www.gentlyoverdone.com', 'href': 'https://www.gentlyoverdone.com'}, {'text': '💝\n  Spenden', 'href': 'https://www.gofundme.com/f/magnitudo?utm_campaign=unknown&utm_medium=referral&utm_source=widget'}]
- **images:** []
- **scripts:** []
- **forms:** 0
- **content_length:** 147373

### metadata.json
- **Type:** json
- **Size:** 104 bytes
- **Extension:** .json
- **error:** name 'v' is not defined

