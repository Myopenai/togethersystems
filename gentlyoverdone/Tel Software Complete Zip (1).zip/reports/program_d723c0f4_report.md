# Program Analysis Report - d723c0f4

**Original File:** Metamorphosis Html.html
**Source URL:** https://tel1.jouwweb.nl/_downloads/ca7b947ce31f10ed3b2bdea193703e44
**File Size:** 56973 bytes
**Content Type:** text/html; charset=UTF-8

## File Analysis

### metadata.json
- **Type:** json
- **Size:** 85 bytes
- **Extension:** .json
- **error:** name 'v' is not defined

### Metamorphosis Html.html
- **Type:** html
- **Size:** 56973 bytes
- **Extension:** .html
- **title:** Metamorphosis — A Gaze That Breaks Through
- **headings:** ['🌸 Welcome to Metamorphosis', "📖 Here's how it works:", '🎨 Settings:', 'Métamorphosis']
- **links:** [{'text': 'gentlyoverdone@outlook.com', 'href': 'mailto:gentlyoverdone@outlook.com'}, {'text': 'Phone: +31 6 1380 3782', 'href': 'tel:+31613803782'}, {'text': 'www.tel1.nl', 'href': 'https://tel1.jouwweb.nl/-2'}, {'text': 'Donate now via GoFundMe', 'href': 'https://www.gofundme.com/f/magnitudo?utm_campaign=unknown&utm_medium=referral&utm_source=widget'}]
- **images:** []
- **scripts:** []
- **forms:** 0
- **content_length:** 56667

