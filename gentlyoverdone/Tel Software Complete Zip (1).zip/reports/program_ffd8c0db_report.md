# Program Analysis Report - ffd8c0db

**Original File:** Raymond Demitrio Tel Info Portal Html.html
**Source URL:** https://tel1.jouwweb.nl/_downloads/2e08fcf0b25b4c201016ce55d358a7ac
**File Size:** 32860 bytes
**Content Type:** text/html; charset=UTF-8

## File Analysis

### metadata.json
- **Type:** json
- **Size:** 104 bytes
- **Extension:** .json
- **error:** name 'v' is not defined

### Raymond Demitrio Tel Info Portal Html.html
- **Type:** html
- **Size:** 32860 bytes
- **Extension:** .html
- **title:** Raymond Tel Portal - TEL&Gentlyoverdone
- **headings:** ['Raymond Tel Portal - TEL&Gentlyoverdone', '🎸 Willkommen bei TEL&Gentlyoverdone', '🎵 Spotify Playlist', '📺 YouTube Playlist', '🎵 Tracks', '🎵 Spotify', '📺 YouTube', '🎤 Interview — De Kentering Nijmegen', 'Gently Overdone Band', '🎸 GENTLY OVERDONE', '💬 Interview mit Gitarrist Raymond Demitrio Tel', '💻 Software & Downloads', '🔬 Science And Electricity Cost Analyzer', '📚 Cursor Ontwikkelingsgids', '🎁 TEL Geschenk Package', '🔥 Werrkvoorbeeld H10', '🆓 FreePrompter', '⚛️ Element-Kombinator CuZn', '🔗 Verifizierte Links', '🎵 Spotify', '📺 YouTube', '💻 TEL1.nl', '💾 Downloads', '💰 GoFundMe', '🎤 Interview', '👤 Über Raymond Demitrio Tel', '🎵 Musik', '💻 Software', '💰 Magnitudo Musica Mundo', '🎯 Ziel: €33.000']
- **links:** [{'text': '🔗 Auf Spotify öffnen', 'href': 'https://open.spotify.com/playlist/7BXr0cyoKuJSH6NUdPkrQ4'}, {'text': '🔗 Auf YouTube öffnen', 'href': 'https://www.youtube.com/watch?v=zoWHvD4S9UM&list=PLCE4Plp9QXA5y1yQDFd0l7Mrd-jZDKZZc'}, {'text': '🔗 Playlist öffnen', 'href': 'https://open.spotify.com/playlist/7BXr0cyoKuJSH6NUdPkrQ4'}, {'text': '🔗 Videos ansehen', 'href': 'https://www.youtube.com/watch?v=zoWHvD4S9UM&list=PLCE4Plp9QXA5y1yQDFd0l7Mrd-jZDKZZc'}, {'text': 'dekentering.info', 'href': 'https://www.dekentering.info/interview-rockband-gently-overdone-muziek-kan-mooie-herinneringen-laten-herleven/'}, {'text': '🎸 GENTLY OVERDONE\nBand Foto\nKlick → tel1.jouwweb.nl', 'href': 'https://tel1.jouwweb.nl/'}, {'text': 'tel1.jouwweb.nl/servicesoftware', 'href': 'https://tel1.jouwweb.nl/servicesoftware'}, {'text': '📥 Download', 'href': 'https://tel1.jouwweb.nl/servicesoftware'}, {'text': '📥 Download', 'href': 'https://tel1.jouwweb.nl/servicesoftware'}, {'text': '📥 Download', 'href': 'https://tel1.jouwweb.nl/servicesoftware'}, {'text': '📥 Download', 'href': 'https://tel1.jouwweb.nl/servicesoftware'}, {'text': '🔗 Ansehen', 'href': 'https://tel1.jouwweb.nl/servicesoftware'}, {'text': '🔗 Analysieren', 'href': 'https://tel1.jouwweb.nl/servicesoftware'}, {'text': '🌐 Alle Downloads auf TEL1.nl', 'href': 'https://tel1.jouwweb.nl/servicesoftware'}, {'text': '🔗 Öffnen', 'href': 'https://open.spotify.com/playlist/7BXr0cyoKuJSH6NUdPkrQ4'}, {'text': '🔗 Öffnen', 'href': 'https://www.youtube.com/watch?v=zoWHvD4S9UM&list=PLCE4Plp9QXA5y1yQDFd0l7Mrd-jZDKZZc'}, {'text': '🔗 Öffnen', 'href': 'https://tel1.jouwweb.nl/'}, {'text': '🔗 Öffnen', 'href': 'https://tel1.jouwweb.nl/servicesoftware'}, {'text': '🔗 Öffnen', 'href': 'https://www.gofundme.com/f/magnitudo'}, {'text': '🔗 Öffnen', 'href': 'https://www.dekentering.info/interview-rockband-gently-overdone-muziek-kan-mooie-herinneringen-laten-herleven/'}, {'text': '💰 Jetzt spenden', 'href': 'https://www.gofundme.com/f/magnitudo'}]
- **images:** []
- **scripts:** []
- **forms:** 0
- **content_length:** 31833

