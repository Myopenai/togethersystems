# Program Analysis Report - f8f0b88f

**Original File:** Science And Electricity Cost Analyzer Zip.zip
**Source URL:** https://tel1.jouwweb.nl/_downloads/570367c612496c07ded2108564a192ce
**File Size:** 203026 bytes
**Content Type:** application/zip

## File Analysis

### CMS-SYSTEM-RDTEL.zip
- **Type:** zip
- **Size:** 36679 bytes
- **Extension:** .zip
- **file_count:** 1
- **files:** ['index.htm']
- **total_size:** 246508

### EU-URBAN-COMPLETE-INTEGRATED-TOOLKIT.html
- **Type:** html
- **Size:** 64580 bytes
- **Extension:** .html
- **title:** EU Urban Complete Toolkit - NL + Multi-City + Node-RED + Qt
- **headings:** ['🏛️ EU Urban Complete Integrated Toolkit', '🎯 Complete Systeem Overzicht', '📦 Complete Module Matrix', '🌍 Supported Cities & Countries', '🇳🇱 Nederland', '🇩🇪 Deutschland', '🇦🇹 Österreich', '🇫🇷 France', '🇮🇹 Italia', '🇪🇸 España', '🚀 Quickstart Workflows', '⚙️ EU Setup & Configuration', '🔌 Proxy Configuration', '📚 Repository Bronnen', '🏙️ Kommunal Adapters (8+ Cities)', '🌍 Stadt Selectie', '📊 Beschikbare Adapters', '🧮 AERIUS Stikstof Calculator (NL)', '📍 Projectgegevens', '🏗️ Bouwfase', '📊 AERIUS Resultaten', '🔴 Node-RED Custom Node', '📦 Package Info', '⚙️ Node Configuration', '🔄 Voorbeeld Flow', '💾 Downloads', '📦 Complete Package', '🔄 Example Flow', '🖥️ Qt/PySide6 Desktop Viewer', '🐍 Vereisten', '📦 Installatie', '✨ Features', '🎨 Screenshot Preview', '🔧 Configuratie', '💾 Downloads', '🐍 Python Script', '📦 PyInstaller Spec', '📋 adapters.json - Complete Definition', '📊 Schema Info', '🌍 Complete adapters.json', '💾 Downloads', '🌍 INSPIRE/OGC Integration', '📚 Supported Standards', '🔗 INSPIRE Endpoints', '📖 WFS Query Template', '🗺️ OSM Overpass Query Template', '🔧 Testing Tools', '🧪 Test Resultaten', '💾 Complete Downloads Center', '📦 Node-RED Package', '🔴 node-red-contrib-urban-adapters', '🔄 Example Flow', '🖥️ Qt/PySide6 Viewer', '🐍 qt-urban-viewer.py', '📦 PyInstaller Spec', '📋 Configuration Files', '📄 adapters.json', '📐 adapters.schema.json', '🧩 Proxy System', '☁️ proxy-worker.js', '📚 Deployment Guide', '🇳🇱 NL Middenhuur Templates', '📊 AERIUS Excel Template', '📄 Salderingscontract']
- **links:** []
- **images:** []
- **scripts:** []
- **forms:** 0
- **content_length:** 63917

### indexwwwapplications.htm
- **Type:** html
- **Size:** 246508 bytes
- **Extension:** .htm
- **title:** Advanced Builder - Vollständig Funktional
- **headings:** ['🚀 Schnell-Komponenten', '📝 Grundlegende Komponenten\n                    ℹ️ Info', '🔄 MODX Extras & Add-ons', '⚡ Erweiterte Widgets', '🚀 Enterprise Features', '📋 MODX Templates', '⚙️ MODX System Settings', '🌐 Website-Einstellungen', '🔒 Sicherheit', '📧 E-Mail-Einstellungen', '🔍 SEO & Analytics', '🌐 Erweiterte Einstellungen', '🖼️ Bild hochladen', '✏️ Komponente bearbeiten']
- **links:** [{'text': 'ℹ️ Info', 'href': 'javascript:void(0)'}]
- **images:** []
- **scripts:** []
- **forms:** 0
- **content_length:** 245052

### presentation-spread-it-psi.html
- **Type:** html
- **Size:** 3021 bytes
- **Extension:** .html
- **title:** TEL & Gentlyoverdone
- **headings:** ['TEL & Gentlyoverdone', '🎧 Beluister Gentlyoverdone op Spotify', '🎧 Beluister Gentlyoverdonelivestudio op Spotify', '📺 Bekijk Gentlyoverdone op YouTube', '📺 Bekijk Gentlyoverdonelivestudio op YouTube', 'Volg ons op sociale media']
- **links:** [{'text': 'Instagram', 'href': 'https://www.instagram.com/gentlyoverdone'}, {'text': 'Facebook', 'href': 'https://www.facebook.com/gentlyoverdone'}, {'text': 'Twitter', 'href': 'https://twitter.com/gentlyoverdone'}]
- **images:** []
- **scripts:** []
- **forms:** 0
- **content_length:** 3009

### TEL-LMS-COMPLETE.html
- **Type:** html
- **Size:** 40005 bytes
- **Extension:** .html
- **title:** 🎓 TEL International LMS - Ausgebreitetes Lernprogramm
- **headings:** ['🌍 International Learning Management System', '🎓 Universitäre Partner', 'MIT OpenCourseWare', 'Stanford Online', 'TU Dresden', 'Nederlands Instituut van Psychologen', 'TU Delft', 'ETH Zürich', 'European Space Agency', '📚 Courseware Plattformen', 'edX', 'Coursera', 'FutureLearn', 'Udacity', 'Pluralsight', 'Khan Academy', '🧠 Psychologie-Optimiertes Lernen', 'Rage-Click Detection', 'Hesitation Tracking', 'Stress Monitoring', 'Adaptive Content', '🏆 Professionelle Zertifikate', 'Google Certificates', 'Microsoft Learn', 'AWS Training', 'TEL International LMS', 'Schnellzugriff', 'Support', 'Kurse']
- **links:** []
- **images:** []
- **scripts:** []
- **forms:** 0
- **content_length:** 39521

### 🎓 TEL International LMS - Ausgebreitetes Lernprogramm.html
- **Type:** html
- **Size:** 45121 bytes
- **Extension:** .html
- **title:** 🎓 TEL International LMS - Ausgebreitetes Lernprogramm
- **headings:** ['🌍 International Learning Management System', '🎓 Universitäre Partner', 'MIT OpenCourseWare', 'Stanford Online', 'TU Dresden', 'Nederlands Instituut van Psychologen', 'TU Delft', 'ETH Zürich', 'European Space Agency', '📚 Courseware Plattformen', 'edX', 'Coursera', 'FutureLearn', 'Udacity', 'Pluralsight', 'Khan Academy', '🧠 Psychologie-Optimiertes Lernen', 'Rage-Click Detection', 'Hesitation Tracking', 'Stress Monitoring', 'Adaptive Content', '🏆 Professionelle Zertifikate', 'Google Certificates', 'Microsoft Learn', 'AWS Training', 'TEL International LMS', 'Schnellzugriff', 'Support', '📚 Alle Kurse', '🎓 Universitätskurse', '📚 Platform Kurse']
- **links:** []
- **images:** []
- **scripts:** []
- **forms:** 0
- **content_length:** 44564

### 🎓 TEL International LMS - Komplettes Lernprogramm - interaktive.html
- **Type:** html
- **Size:** 21650 bytes
- **Extension:** .html
- **title:** 🎓 TEL International LMS - Komplettes Lernprogramm
- **headings:** ['🌍 TEL International LMS', '🎓 7 Universitäre Partner', 'MIT OpenCourseWare', 'Stanford Online', 'TU Dresden', 'Nederlands Instituut', 'TU Delft', 'ETH Zürich', 'ESA', '📚 6 Courseware Plattformen', 'edX', 'Coursera', 'FutureLearn', 'Udacity', 'Pluralsight', 'Khan Academy', '🧠 Psychologie-Optimiertes Lernen', 'Rage-Click Detection', 'Hesitation Tracking', 'Stress Monitoring', 'Adaptive Content', '🏆 Professionelle Zertifikate', 'Google Certificates', 'Microsoft Learn', 'AWS Training', 'TEL International LMS', 'Kontakt', '🎵 Magnitudo Musica Mundo', '👆 Rage-Click Detection', 'Was ist Rage-Click Detection?', 'Wie funktioniert es?', 'Probieren Sie es:']
- **links:** [{'text': 'tinyurl.com/MMM2030', 'href': 'https://tinyurl.com/MMM2030'}]
- **images:** []
- **scripts:** []
- **forms:** 0
- **content_length:** 21348

### 🎓 TEL International LMS - Komplettes Lernprogramm.html
- **Type:** html
- **Size:** 11492 bytes
- **Extension:** .html
- **title:** 🎓 TEL International LMS - Komplettes Lernprogramm
- **headings:** ['🌍 TEL International LMS', '🎓 7 Universitäre Partner', 'MIT OpenCourseWare', 'Stanford Online', 'TU Dresden', 'Nederlands Instituut Psychologen', 'TU Delft', 'ETH Zürich', 'European Space Agency', '📚 6 Courseware Plattformen', 'edX', 'Coursera', 'FutureLearn', 'Udacity', 'Pluralsight', 'Khan Academy', '🧠 Psychologie-Optimiertes Lernen', 'Rage-Click Detection', 'Hesitation Tracking', 'Stress Monitoring', 'Adaptive Content', '🏆 Professionelle Zertifikate', 'Google Certificates', 'Microsoft Learn', 'AWS Training', 'TEL International LMS', 'Kontakt', 'Features']
- **links:** [{'text': 'Universitäten', 'href': '#unis'}, {'text': 'Plattformen', 'href': '#plat'}, {'text': 'Zertifikate', 'href': '#cert'}, {'text': 'Magnitudo Musica Mundo', 'href': 'https://tinyurl.com/MMM2030'}]
- **images:** []
- **scripts:** []
- **forms:** 0
- **content_length:** 11344

### Stromkosten-Analyzer-ALL-IN-ONE.py
- **Type:** python
- **Size:** 21000 bytes
- **Extension:** .py
- **imports:** ['sys', 'os', 'platform', 'subprocess', 'threading', 'webbrowser', 'time', 'json', 'Path', 'Flask', 'CORS', 'dataclass', 'Dict', 'datetime', 'hashlib', 'urllib']
- **functions:** ['check_and_install_dependencies', '__init__', 'kosten', 'berechne_kosten', 'index', 'health', 'datenbank', 'berechnen', '__init__', 'print_banner', 'start_backend', 'run_server', 'wait_for_backend', 'open_browser', 'show_instructions', 'run']
- **classes:** ['from', 'class', 'class', 'StromkostenCalculator', 'AllInOneLauncher']
- **content_length:** 20860
- **lines:** 620

### ULTIMATE-PRODUCTION-CENTER.html
- **Type:** html
- **Size:** 271822 bytes
- **Extension:** .html
- **title:** 🏭 ULTIMATIVES PRODUKTIONSZENTRUM — Visualisierung & Orchestrierung (Demo)
- **headings:** ['🏭 ULTIMATIVES PRODUKTIONSZENTRUM', 'OEE', 'First-Pass Yield', 'Energie / Stunde', 'Anlagenverfügbarkeit', 'Live-Status', 'Produkt-Galerie', '', 'Letzte QA-Ergebnisse', 'Industrie-Prozessfluss (Beispiel)', 'Rezept anlegen', 'Rezepte', 'Runs', 'Audit-Trail (lokal)']
- **links:** []
- **images:** []
- **scripts:** []
- **forms:** 0
- **content_length:** 271740

