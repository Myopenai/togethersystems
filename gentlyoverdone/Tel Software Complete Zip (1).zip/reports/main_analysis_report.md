# TEL1.nl Website Analysis Report

**Analysis Date:** 2025-10-22 20:46:47
**Base URL:** https://tel1.jouwweb.nl/
**Max Depth:** 10000
**Total Downloads Found:** 250
**Successfully Extracted:** 250

## Downloads Overview

### d86c45f8 - index.html
- **URL:** https://bunqbank.w3spaces.com/index.html
- **Size:** 55947 bytes
- **Type:** text/html
- **Link Text:** BunqBank
- **Extraction:** ✅ Success

### d86c45f8 - index.html
- **URL:** https://bunqbank.w3spaces.com/index.html
- **Size:** 55947 bytes
- **Type:** text/html
- **Link Text:** BunqBank
- **Extraction:** ✅ Success

### d86c45f8 - index.html
- **URL:** https://bunqbank.w3spaces.com/index.html
- **Size:** 55947 bytes
- **Type:** text/html
- **Link Text:** BunqBank
- **Extraction:** ✅ Success

### d86c45f8 - index.html
- **URL:** https://bunqbank.w3spaces.com/index.html
- **Size:** 55947 bytes
- **Type:** text/html
- **Link Text:** BunqBank
- **Extraction:** ✅ Success

### d86c45f8 - index.html
- **URL:** https://bunqbank.w3spaces.com/index.html
- **Size:** 55947 bytes
- **Type:** text/html
- **Link Text:** BunqBank
- **Extraction:** ✅ Success

### d86c45f8 - index.html
- **URL:** https://bunqbank.w3spaces.com/index.html
- **Size:** 55947 bytes
- **Type:** text/html
- **Link Text:** BunqBank
- **Extraction:** ✅ Success

### d86c45f8 - index.html
- **URL:** https://bunqbank.w3spaces.com/index.html
- **Size:** 55947 bytes
- **Type:** text/html
- **Link Text:** BunqBank
- **Extraction:** ✅ Success

### d86c45f8 - index.html
- **URL:** https://bunqbank.w3spaces.com/index.html
- **Size:** 55947 bytes
- **Type:** text/html
- **Link Text:** BunqBank
- **Extraction:** ✅ Success

### d86c45f8 - index.html
- **URL:** https://bunqbank.w3spaces.com/index.html
- **Size:** 55947 bytes
- **Type:** text/html
- **Link Text:** BunqBank
- **Extraction:** ✅ Success

### d86c45f8 - index.html
- **URL:** https://bunqbank.w3spaces.com/index.html
- **Size:** 55947 bytes
- **Type:** text/html
- **Link Text:** BunqBank
- **Extraction:** ✅ Success

### d86c45f8 - index.html
- **URL:** https://bunqbank.w3spaces.com/index.html
- **Size:** 55947 bytes
- **Type:** text/html
- **Link Text:** BunqBank
- **Extraction:** ✅ Success

### d86c45f8 - index.html
- **URL:** https://bunqbank.w3spaces.com/index.html
- **Size:** 55947 bytes
- **Type:** text/html
- **Link Text:** BunqBank
- **Extraction:** ✅ Success

### d86c45f8 - index.html
- **URL:** https://bunqbank.w3spaces.com/index.html
- **Size:** 55947 bytes
- **Type:** text/html
- **Link Text:** BunqBank
- **Extraction:** ✅ Success

### d86c45f8 - index.html
- **URL:** https://bunqbank.w3spaces.com/index.html
- **Size:** 55947 bytes
- **Type:** text/html
- **Link Text:** BunqBank
- **Extraction:** ✅ Success

### d86c45f8 - index.html
- **URL:** https://bunqbank.w3spaces.com/index.html
- **Size:** 55947 bytes
- **Type:** text/html
- **Link Text:** BunqBank
- **Extraction:** ✅ Success

### 5527cd69 - Tel Geschenk Package All Languages With Cover Zip.zip
- **URL:** https://tel1.jouwweb.nl/_downloads/cdf7ef34db189368dbfe81dafffe2078
- **Size:** 50472 bytes
- **Type:** application/zip
- **Link Text:** Download
- **Extraction:** ✅ Success

### 9db06b57 - Werrkvoorbeeld H 10.docx
- **URL:** https://tel1.jouwweb.nl/_downloads/807f7c4beea346aba09b6a5a719d4695
- **Size:** 5542 bytes
- **Type:** application/vnd.openxmlformats-officedocument.wordprocessingml.document
- **Link Text:** Download
- **Extraction:** ✅ Success

### 2d1ab3fb - university.html
- **URL:** https://digitalnotar.in/university.html
- **Size:** 52983 bytes
- **Type:** text/html
- **Link Text:** APRODUCTIONWORKSSHOPA
- **Extraction:** ✅ Success

### 2d1ab3fb - university.html
- **URL:** https://digitalnotar.in/university.html
- **Size:** 52983 bytes
- **Type:** text/html
- **Link Text:** VOLLVERSION
- **Extraction:** ✅ Success

### 2d1ab3fb - university.html
- **URL:** https://digitalnotar.in/university.html
- **Size:** 52983 bytes
- **Type:** text/html
- **Link Text:** 🎸 TEL Portal - All-In-One für alle Geräte
- **Extraction:** ✅ Success

### 2d1ab3fb - university.html
- **URL:** https://digitalnotar.in/university.html
- **Size:** 52983 bytes
- **Type:** text/html
- **Link Text:** 🎸 TEL Portal - All-In-One für alle Geräte
- **Extraction:** ✅ Success

### bbb42eaa - schermafbeelding-2025-08-24-034132-high.png
- **URL:** https://primary.jwwb.nl/public/h/o/b/temp-nyratlbjkkriqxftlyfy/schermafbeelding-2025-08-24-034132-high.png
- **Size:** 72377 bytes
- **Type:** image/png
- **Link Text:** Gitarr HTML
- **Extraction:** ✅ Success

### 952e0516 - Gitarre Html 1 Html.html
- **URL:** https://tel1.jouwweb.nl/_downloads/00869c1ca30df16238fca9fedf5ef714
- **Size:** 79180 bytes
- **Type:** text/html; charset=UTF-8
- **Link Text:** Download
- **Extraction:** ✅ Success

### fb881951 - Documentation Zip.zip
- **URL:** https://tel1.jouwweb.nl/_downloads/6551b8dd79606b5833a64636fde65c43
- **Size:** 48767 bytes
- **Type:** application/zip
- **Link Text:** Download
- **Extraction:** ✅ Success

### 0e6b4c8b - Testversion 0001 Gitarre Html Zip.zip
- **URL:** https://tel1.jouwweb.nl/_downloads/f615236d9b97c44bc0f0a9120a167ecc
- **Size:** 88863 bytes
- **Type:** application/zip
- **Link Text:** Download
- **Extraction:** ✅ Success

### 5527cd69 - Tel Geschenk Package All Languages With Cover Zip.zip
- **URL:** https://tel1.jouwweb.nl/_downloads/cdf7ef34db189368dbfe81dafffe2078
- **Size:** 50472 bytes
- **Type:** application/zip
- **Link Text:** Download
- **Extraction:** ✅ Success

### 9db06b57 - Werrkvoorbeeld H 10.docx
- **URL:** https://tel1.jouwweb.nl/_downloads/807f7c4beea346aba09b6a5a719d4695
- **Size:** 5542 bytes
- **Type:** application/vnd.openxmlformats-officedocument.wordprocessingml.document
- **Link Text:** Download
- **Extraction:** ✅ Success

### 2d1ab3fb - university.html
- **URL:** https://digitalnotar.in/university.html
- **Size:** 52983 bytes
- **Type:** text/html
- **Link Text:** APRODUCTIONWORKSSHOPA
- **Extraction:** ✅ Success

### 2d1ab3fb - university.html
- **URL:** https://digitalnotar.in/university.html
- **Size:** 52983 bytes
- **Type:** text/html
- **Link Text:** VOLLVERSION
- **Extraction:** ✅ Success

### 2d1ab3fb - university.html
- **URL:** https://digitalnotar.in/university.html
- **Size:** 52983 bytes
- **Type:** text/html
- **Link Text:** 🎸 TEL Portal - All-In-One für alle Geräte
- **Extraction:** ✅ Success

### 2d1ab3fb - university.html
- **URL:** https://digitalnotar.in/university.html
- **Size:** 52983 bytes
- **Type:** text/html
- **Link Text:** 🎸 TEL Portal - All-In-One für alle Geräte
- **Extraction:** ✅ Success

### 26b576a5 - Pre Gitarre Html 2 Html.html
- **URL:** https://tel1.jouwweb.nl/_downloads/cfac5912f71a49524a68686bcb571f2a
- **Size:** 79180 bytes
- **Type:** text/html; charset=UTF-8
- **Link Text:** Download
- **Extraction:** ✅ Success

### 88939a6f - Documentation Zip Zip.zip
- **URL:** https://tel1.jouwweb.nl/_downloads/99bd1c4f5273a633124dbafbaab184ac
- **Size:** 48767 bytes
- **Type:** application/zip
- **Link Text:** Download
- **Extraction:** ✅ Success

### c458ade2 - Testversion 0001 Gitarre Html Zip 1 Zip.zip
- **URL:** https://tel1.jouwweb.nl/_downloads/caa9e581973098c0e09ec9846c620e3e
- **Size:** 88863 bytes
- **Type:** application/zip
- **Link Text:** Download
- **Extraction:** ✅ Success

### 5527cd69 - Tel Geschenk Package All Languages With Cover Zip.zip
- **URL:** https://tel1.jouwweb.nl/_downloads/cdf7ef34db189368dbfe81dafffe2078
- **Size:** 50472 bytes
- **Type:** application/zip
- **Link Text:** Download
- **Extraction:** ✅ Success

### 9db06b57 - Werrkvoorbeeld H 10.docx
- **URL:** https://tel1.jouwweb.nl/_downloads/807f7c4beea346aba09b6a5a719d4695
- **Size:** 5542 bytes
- **Type:** application/vnd.openxmlformats-officedocument.wordprocessingml.document
- **Link Text:** Download
- **Extraction:** ✅ Success

### 2d1ab3fb - university.html
- **URL:** https://digitalnotar.in/university.html
- **Size:** 52983 bytes
- **Type:** text/html
- **Link Text:** APRODUCTIONWORKSSHOPA
- **Extraction:** ✅ Success

### 2d1ab3fb - university.html
- **URL:** https://digitalnotar.in/university.html
- **Size:** 52983 bytes
- **Type:** text/html
- **Link Text:** VOLLVERSION
- **Extraction:** ✅ Success

### 2d1ab3fb - university.html
- **URL:** https://digitalnotar.in/university.html
- **Size:** 52983 bytes
- **Type:** text/html
- **Link Text:** 🎸 TEL Portal - All-In-One für alle Geräte
- **Extraction:** ✅ Success

### 2d1ab3fb - university.html
- **URL:** https://digitalnotar.in/university.html
- **Size:** 52983 bytes
- **Type:** text/html
- **Link Text:** 🎸 TEL Portal - All-In-One für alle Geräte
- **Extraction:** ✅ Success

### d0221263 - Documentation Zip.zip
- **URL:** https://tel1.jouwweb.nl/_downloads/1074975bf129e55070690fc5e3d568e5
- **Size:** 48767 bytes
- **Type:** application/zip
- **Link Text:** Download
- **Extraction:** ✅ Success

### 0b6e1f9b - Testversion 0001 Gitarre Html Zip.zip
- **URL:** https://tel1.jouwweb.nl/_downloads/3444bf362682e848cb2bd7b7a2633d66
- **Size:** 88863 bytes
- **Type:** application/zip
- **Link Text:** Download
- **Extraction:** ✅ Success

### 5527cd69 - Tel Geschenk Package All Languages With Cover Zip.zip
- **URL:** https://tel1.jouwweb.nl/_downloads/cdf7ef34db189368dbfe81dafffe2078
- **Size:** 50472 bytes
- **Type:** application/zip
- **Link Text:** Download
- **Extraction:** ✅ Success

### 9db06b57 - Werrkvoorbeeld H 10.docx
- **URL:** https://tel1.jouwweb.nl/_downloads/807f7c4beea346aba09b6a5a719d4695
- **Size:** 5542 bytes
- **Type:** application/vnd.openxmlformats-officedocument.wordprocessingml.document
- **Link Text:** Download
- **Extraction:** ✅ Success

### 2d1ab3fb - university.html
- **URL:** https://digitalnotar.in/university.html
- **Size:** 52983 bytes
- **Type:** text/html
- **Link Text:** APRODUCTIONWORKSSHOPA
- **Extraction:** ✅ Success

### 2d1ab3fb - university.html
- **URL:** https://digitalnotar.in/university.html
- **Size:** 52983 bytes
- **Type:** text/html
- **Link Text:** VOLLVERSION
- **Extraction:** ✅ Success

### 2d1ab3fb - university.html
- **URL:** https://digitalnotar.in/university.html
- **Size:** 52983 bytes
- **Type:** text/html
- **Link Text:** 🎸 TEL Portal - All-In-One für alle Geräte
- **Extraction:** ✅ Success

### 2d1ab3fb - university.html
- **URL:** https://digitalnotar.in/university.html
- **Size:** 52983 bytes
- **Type:** text/html
- **Link Text:** 🎸 TEL Portal - All-In-One für alle Geräte
- **Extraction:** ✅ Success

### 5527cd69 - Tel Geschenk Package All Languages With Cover Zip.zip
- **URL:** https://tel1.jouwweb.nl/_downloads/cdf7ef34db189368dbfe81dafffe2078
- **Size:** 50472 bytes
- **Type:** application/zip
- **Link Text:** Download
- **Extraction:** ✅ Success

### 9db06b57 - Werrkvoorbeeld H 10.docx
- **URL:** https://tel1.jouwweb.nl/_downloads/807f7c4beea346aba09b6a5a719d4695
- **Size:** 5542 bytes
- **Type:** application/vnd.openxmlformats-officedocument.wordprocessingml.document
- **Link Text:** Download
- **Extraction:** ✅ Success

### 2d1ab3fb - university.html
- **URL:** https://digitalnotar.in/university.html
- **Size:** 52983 bytes
- **Type:** text/html
- **Link Text:** APRODUCTIONWORKSSHOPA
- **Extraction:** ✅ Success

### 2d1ab3fb - university.html
- **URL:** https://digitalnotar.in/university.html
- **Size:** 52983 bytes
- **Type:** text/html
- **Link Text:** VOLLVERSION
- **Extraction:** ✅ Success

### 2d1ab3fb - university.html
- **URL:** https://digitalnotar.in/university.html
- **Size:** 52983 bytes
- **Type:** text/html
- **Link Text:** 🎸 TEL Portal - All-In-One für alle Geräte
- **Extraction:** ✅ Success

### 2d1ab3fb - university.html
- **URL:** https://digitalnotar.in/university.html
- **Size:** 52983 bytes
- **Type:** text/html
- **Link Text:** 🎸 TEL Portal - All-In-One für alle Geräte
- **Extraction:** ✅ Success

### 5527cd69 - Tel Geschenk Package All Languages With Cover Zip.zip
- **URL:** https://tel1.jouwweb.nl/_downloads/cdf7ef34db189368dbfe81dafffe2078
- **Size:** 50472 bytes
- **Type:** application/zip
- **Link Text:** Download
- **Extraction:** ✅ Success

### 9db06b57 - Werrkvoorbeeld H 10.docx
- **URL:** https://tel1.jouwweb.nl/_downloads/807f7c4beea346aba09b6a5a719d4695
- **Size:** 5542 bytes
- **Type:** application/vnd.openxmlformats-officedocument.wordprocessingml.document
- **Link Text:** Download
- **Extraction:** ✅ Success

### 2d1ab3fb - university.html
- **URL:** https://digitalnotar.in/university.html
- **Size:** 52983 bytes
- **Type:** text/html
- **Link Text:** APRODUCTIONWORKSSHOPA
- **Extraction:** ✅ Success

### 2d1ab3fb - university.html
- **URL:** https://digitalnotar.in/university.html
- **Size:** 52983 bytes
- **Type:** text/html
- **Link Text:** VOLLVERSION
- **Extraction:** ✅ Success

### 2d1ab3fb - university.html
- **URL:** https://digitalnotar.in/university.html
- **Size:** 52983 bytes
- **Type:** text/html
- **Link Text:** 🎸 TEL Portal - All-In-One für alle Geräte
- **Extraction:** ✅ Success

### 2d1ab3fb - university.html
- **URL:** https://digitalnotar.in/university.html
- **Size:** 52983 bytes
- **Type:** text/html
- **Link Text:** 🎸 TEL Portal - All-In-One für alle Geräte
- **Extraction:** ✅ Success

### 36da075f - Gentlyoverdone Mp 4.mp4
- **URL:** https://tel1.jouwweb.nl/_downloads/b022b026f7a5fd1792413a61454000e8
- **Size:** 2167108 bytes
- **Type:** video/mp4
- **Link Text:** Download
- **Extraction:** ✅ Success

### 5527cd69 - Tel Geschenk Package All Languages With Cover Zip.zip
- **URL:** https://tel1.jouwweb.nl/_downloads/cdf7ef34db189368dbfe81dafffe2078
- **Size:** 50472 bytes
- **Type:** application/zip
- **Link Text:** Download
- **Extraction:** ✅ Success

### 9db06b57 - Werrkvoorbeeld H 10.docx
- **URL:** https://tel1.jouwweb.nl/_downloads/807f7c4beea346aba09b6a5a719d4695
- **Size:** 5542 bytes
- **Type:** application/vnd.openxmlformats-officedocument.wordprocessingml.document
- **Link Text:** Download
- **Extraction:** ✅ Success

### 2d1ab3fb - university.html
- **URL:** https://digitalnotar.in/university.html
- **Size:** 52983 bytes
- **Type:** text/html
- **Link Text:** APRODUCTIONWORKSSHOPA
- **Extraction:** ✅ Success

### 2d1ab3fb - university.html
- **URL:** https://digitalnotar.in/university.html
- **Size:** 52983 bytes
- **Type:** text/html
- **Link Text:** VOLLVERSION
- **Extraction:** ✅ Success

### 2d1ab3fb - university.html
- **URL:** https://digitalnotar.in/university.html
- **Size:** 52983 bytes
- **Type:** text/html
- **Link Text:** 🎸 TEL Portal - All-In-One für alle Geräte
- **Extraction:** ✅ Success

### 2d1ab3fb - university.html
- **URL:** https://digitalnotar.in/university.html
- **Size:** 52983 bytes
- **Type:** text/html
- **Link Text:** 🎸 TEL Portal - All-In-One für alle Geräte
- **Extraction:** ✅ Success

### 2d28c0c8 - Psy Ai Complete Doku 2025 Zip.zip
- **URL:** https://tel1.jouwweb.nl/_downloads/027eb7f4fd4b7d1d89a459e9455cc350
- **Size:** 8791 bytes
- **Type:** application/zip
- **Link Text:** Download
- **Extraction:** ✅ Success

### cfbe2ba7 - schermafbeelding-2025-10-15-145647-high.png
- **URL:** https://primary.jwwb.nl/public/h/o/b/temp-nyratlbjkkriqxftlyfy/schermafbeelding-2025-10-15-145647-high.png
- **Size:** 171456 bytes
- **Type:** image/png
- **Link Text:** 
- **Extraction:** ✅ Success

### ddd12b3a - Cullinary Mmm Magnitudo Musica Mundo Html.html
- **URL:** https://tel1.jouwweb.nl/_downloads/9ac78d7c7b283e5c53bef23329a20281
- **Size:** 151577 bytes
- **Type:** text/html; charset=UTF-8
- **Link Text:** Download
- **Extraction:** ✅ Success

### ca2ffef0 - schermafbeelding-2025-10-12-164500-high.png
- **URL:** https://primary.jwwb.nl/public/h/o/b/temp-nyratlbjkkriqxftlyfy/schermafbeelding-2025-10-12-164500-high.png
- **Size:** 107242 bytes
- **Type:** image/png
- **Link Text:** 
- **Extraction:** ✅ Success

### f8f0b88f - Science And Electricity Cost Analyzer Zip.zip
- **URL:** https://tel1.jouwweb.nl/_downloads/570367c612496c07ded2108564a192ce
- **Size:** 203026 bytes
- **Type:** application/zip
- **Link Text:** Download
- **Extraction:** ✅ Success

### 97ee7a41 - Relax Html.html
- **URL:** https://tel1.jouwweb.nl/_downloads/b0a82cd0dec55849bc63c0218a0f55fc
- **Size:** 13620 bytes
- **Type:** text/html; charset=UTF-8
- **Link Text:** Download
- **Extraction:** ✅ Success

### dd315618 - Cursor Ontwikkelingsgids Nederlands Zip.zip
- **URL:** https://tel1.jouwweb.nl/_downloads/aa2eb100fe2947f6093796ce675586ce
- **Size:** 11244 bytes
- **Type:** application/zip
- **Link Text:** Download
- **Extraction:** ✅ Success

### ef376cdd - Cursor Ontwikkelingsgids Nederlands 1 Pdf.pdf
- **URL:** https://tel1.jouwweb.nl/_downloads/3bfbeee4545423bf45270eacda4b6ab7
- **Size:** 317910 bytes
- **Type:** application/pdf
- **Link Text:** Download
- **Extraction:** ✅ Success

### d723c0f4 - Metamorphosis Html.html
- **URL:** https://tel1.jouwweb.nl/_downloads/ca7b947ce31f10ed3b2bdea193703e44
- **Size:** 56973 bytes
- **Type:** text/html; charset=UTF-8
- **Link Text:** Download
- **Extraction:** ✅ Success

### 999f654b - Scienceformulars Zip.zip
- **URL:** https://tel1.jouwweb.nl/_downloads/bf8494d4d63d78c3e4aad783e1a0b6f7
- **Size:** 27385 bytes
- **Type:** application/zip
- **Link Text:** Download
- **Extraction:** ✅ Success

### 7c7b91b8 - schermafbeelding-2025-10-14-231043-high.png
- **URL:** https://primary.jwwb.nl/public/h/o/b/temp-nyratlbjkkriqxftlyfy/schermafbeelding-2025-10-14-231043-high.png
- **Size:** 261910 bytes
- **Type:** image/png
- **Link Text:** 
- **Extraction:** ✅ Success

### 80b284a9 - Budget Book 2025 Html.html
- **URL:** https://tel1.jouwweb.nl/_downloads/d166bedcd994ba935232f10ea77befdf
- **Size:** 207187 bytes
- **Type:** text/html; charset=UTF-8
- **Link Text:** Download
- **Extraction:** ✅ Success

### 999f654b - Scienceformulars Zip.zip
- **URL:** https://tel1.jouwweb.nl/_downloads/bf8494d4d63d78c3e4aad783e1a0b6f7
- **Size:** 27385 bytes
- **Type:** application/zip
- **Link Text:** Download
- **Extraction:** ✅ Success

### e376b677 - Call To Action Report Zip.zip
- **URL:** https://tel1.jouwweb.nl/_downloads/91dd675bcb0a8860bc8aeff950d050ef
- **Size:** 6807 bytes
- **Type:** application/zip
- **Link Text:** Download
- **Extraction:** ✅ Success

### 7b602f61 - Html Pool Zip.zip
- **URL:** https://tel1.jouwweb.nl/_downloads/df78bb61ac32f8733deffc980bf3924d
- **Size:** 532323 bytes
- **Type:** application/zip
- **Link Text:** Download
- **Extraction:** ✅ Success

### b5dc3560 - schermafbeelding-2025-10-13-202917-high.png
- **URL:** https://primary.jwwb.nl/public/h/o/b/temp-nyratlbjkkriqxftlyfy/schermafbeelding-2025-10-13-202917-high.png
- **Size:** 249763 bytes
- **Type:** image/png
- **Link Text:** 
- **Extraction:** ✅ Success

### 3d928372 - download_3d928372.bin
- **URL:** https://tel1.jouwweb.nl/servicesoftware
- **Size:** 266134 bytes
- **Type:** text/html; charset=UTF-8
- **Link Text:** 📥 Download
- **Extraction:** ✅ Success

### 3d928372 - download_3d928372.bin
- **URL:** https://tel1.jouwweb.nl/servicesoftware
- **Size:** 272375 bytes
- **Type:** text/html; charset=UTF-8
- **Link Text:** 📥 Download
- **Extraction:** ✅ Success

### 3d928372 - download_3d928372.bin
- **URL:** https://tel1.jouwweb.nl/servicesoftware
- **Size:** 272375 bytes
- **Type:** text/html; charset=UTF-8
- **Link Text:** 📥 Download
- **Extraction:** ✅ Success

### 3d928372 - download_3d928372.bin
- **URL:** https://tel1.jouwweb.nl/servicesoftware
- **Size:** 272379 bytes
- **Type:** text/html; charset=UTF-8
- **Link Text:** 📥 Download
- **Extraction:** ✅ Success

### 3d928372 - download_3d928372.bin
- **URL:** https://tel1.jouwweb.nl/servicesoftware
- **Size:** 266130 bytes
- **Type:** text/html; charset=UTF-8
- **Link Text:** 🌐 Alle Downloads auf TEL1.nl
- **Extraction:** ✅ Success

### ffd8c0db - Raymond Demitrio Tel Info Portal Html.html
- **URL:** https://tel1.jouwweb.nl/_downloads/2e08fcf0b25b4c201016ce55d358a7ac
- **Size:** 32860 bytes
- **Type:** text/html; charset=UTF-8
- **Link Text:** Download
- **Extraction:** ✅ Success

### f579037c - Browser Konsole Handbuch Pdf.pdf
- **URL:** https://tel1.jouwweb.nl/_downloads/01ac1262f616be032dab166c01e07ab1
- **Size:** 108187 bytes
- **Type:** application/pdf
- **Link Text:** Download
- **Extraction:** ✅ Success

### 63bd5d76 - Cursor Sftp One Prompt Pack Zip.zip
- **URL:** https://tel1.jouwweb.nl/_downloads/1060778f7516513ec020b0640b3561d1
- **Size:** 3455 bytes
- **Type:** application/zip
- **Link Text:** Download
- **Extraction:** ✅ Success

### 43cb0b60 - schermafbeelding-2025-08-24-135736-high.png
- **URL:** https://primary.jwwb.nl/public/h/o/b/temp-nyratlbjkkriqxftlyfy/schermafbeelding-2025-08-24-135736-high.png
- **Size:** 102206 bytes
- **Type:** image/png
- **Link Text:** 
- **Extraction:** ✅ Success

### a068075a - Tel 1 Angebotskatalog Aktualisiert Print Html.html
- **URL:** https://tel1.jouwweb.nl/_downloads/3fe9cf7a9645ad930a45ea1c339428c3
- **Size:** 12356 bytes
- **Type:** text/html; charset=UTF-8
- **Link Text:** Download
- **Extraction:** ✅ Success

### 20150ce6 - University Html.html
- **URL:** https://tel1.jouwweb.nl/_downloads/e3ed238e00de74872dd56fb9a0945cdc
- **Size:** 78257 bytes
- **Type:** text/html; charset=UTF-8
- **Link Text:** Download
- **Extraction:** ✅ Success

### bd72cd04 - Cursor Guides Drtel Zip.zip
- **URL:** https://tel1.jouwweb.nl/_downloads/d25af73b7f7cc1fdf468a19be9f96f3f
- **Size:** 41833 bytes
- **Type:** application/zip
- **Link Text:** Download
- **Extraction:** ✅ Success

### 6a0b12d7 - En De Nl Present By Law International Zip.zip
- **URL:** https://tel1.jouwweb.nl/_downloads/2fe9e9440c98a93201d03adeeccd2b9d
- **Size:** 29941 bytes
- **Type:** application/zip
- **Link Text:** Download
- **Extraction:** ✅ Success

### e57b6158 - De En Nl Routines Complete Handbook En Zip.zip
- **URL:** https://tel1.jouwweb.nl/_downloads/af7b006177e276f99c7fd1c40e34d839
- **Size:** 33261 bytes
- **Type:** application/zip
- **Link Text:** Download
- **Extraction:** ✅ Success

### a45c49da - De En Nl Ai Zelf Programming With Law 2025 Db Zip.zip
- **URL:** https://tel1.jouwweb.nl/_downloads/58fe34c41599575c852ca0e76cc2bc2b
- **Size:** 38431 bytes
- **Type:** application/zip
- **Link Text:** Download
- **Extraction:** ✅ Success

### d07cfe46 - schermafbeelding-2025-08-22-154610-high.png
- **URL:** https://primary.jwwb.nl/public/h/o/b/temp-nyratlbjkkriqxftlyfy/schermafbeelding-2025-08-22-154610-high.png
- **Size:** 126871 bytes
- **Type:** image/png
- **Link Text:** 
- **Extraction:** ✅ Success

### 70d32dc2 - Cv R D Tel Html Html.html
- **URL:** https://tel1.jouwweb.nl/_downloads/295026e9d8574f1cca4757dc65a94aa8
- **Size:** 195700 bytes
- **Type:** text/html; charset=UTF-8
- **Link Text:** Download
- **Extraction:** ✅ Success

### 19c2aba7 - Singlefile Html.html
- **URL:** https://tel1.jouwweb.nl/_downloads/a1b2cbecbb5784d2952e2079cc48c5e7
- **Size:** 14569 bytes
- **Type:** text/html; charset=UTF-8
- **Link Text:** Download
- **Extraction:** ✅ Success

### 752a6c33 - schermafbeelding-2025-09-02-030304-high.png
- **URL:** https://primary.jwwb.nl/public/h/o/b/temp-nyratlbjkkriqxftlyfy/schermafbeelding-2025-09-02-030304-high.png
- **Size:** 239383 bytes
- **Type:** image/png
- **Link Text:** 
- **Extraction:** ✅ Success

### b2fadea4 - Musical Education Program Html.html
- **URL:** https://tel1.jouwweb.nl/_downloads/6d931107b710e91c62770301f8940def
- **Size:** 30116 bytes
- **Type:** text/html; charset=UTF-8
- **Link Text:** Download
- **Extraction:** ✅ Success

### 829cccf3 - schermafbeelding-2025-08-22-154536-high.png
- **URL:** https://primary.jwwb.nl/public/h/o/b/temp-nyratlbjkkriqxftlyfy/schermafbeelding-2025-08-22-154536-high.png
- **Size:** 652478 bytes
- **Type:** image/png
- **Link Text:** 
- **Extraction:** ✅ Success

### 1202eee5 - Cms System Htm.htm
- **URL:** https://tel1.jouwweb.nl/_downloads/c29fecc01041cdfbfc1ea3b34a34ddd1
- **Size:** 246508 bytes
- **Type:** text/html; charset=UTF-8
- **Link Text:** Download
- **Extraction:** ✅ Success

### 59a4dda7 - index.html
- **URL:** https://viewunitysystemt.github.io/TELCOTELEKOM/index.html
- **Size:** 419414 bytes
- **Type:** text/html; charset=utf-8
- **Link Text:** Typ hier je tekst
- **Extraction:** ✅ Success

### f20b3995 - schermafbeelding-2025-08-22-154512-high.png
- **URL:** https://primary.jwwb.nl/public/h/o/b/temp-nyratlbjkkriqxftlyfy/schermafbeelding-2025-08-22-154512-high.png
- **Size:** 325199 bytes
- **Type:** image/png
- **Link Text:** 
- **Extraction:** ✅ Success

### 9d318e8e - Globale Meeting Uhr Onefile V 2 Html.html
- **URL:** https://tel1.jouwweb.nl/_downloads/c1f56b3bf6528f5516a8af5857d09dd3
- **Size:** 147560 bytes
- **Type:** text/html; charset=UTF-8
- **Link Text:** Download
- **Extraction:** ✅ Success

### e3b47582 - Timecode Odt.odt
- **URL:** https://tel1.jouwweb.nl/_downloads/b7985206df2cc991f09a5392e298bc2c
- **Size:** 36510 bytes
- **Type:** application/vnd.oasis.opendocument.text
- **Link Text:** Download
- **Extraction:** ✅ Success

### d26a0ff2 - schermafbeelding-2025-08-30-123033-high.png
- **URL:** https://primary.jwwb.nl/public/h/o/b/temp-nyratlbjkkriqxftlyfy/schermafbeelding-2025-08-30-123033-high.png
- **Size:** 177795 bytes
- **Type:** image/png
- **Link Text:** 
- **Extraction:** ✅ Success

### 9c927394 - Markt Fenster Coach Global Zeit Suite Onefile V 3 Html.html
- **URL:** https://tel1.jouwweb.nl/_downloads/a2b8f7150768e196ed7e4b78341374e1
- **Size:** 36374 bytes
- **Type:** text/html; charset=UTF-8
- **Link Text:** Download
- **Extraction:** ✅ Success

### ed8981cc - chatgpt-image-3-sep-2025-22_34_37-high.png
- **URL:** https://primary.jwwb.nl/public/h/o/b/temp-nyratlbjkkriqxftlyfy/chatgpt-image-3-sep-2025-22_34_37-high.png
- **Size:** 2212278 bytes
- **Type:** image/png
- **Link Text:** 
- **Extraction:** ✅ Success

### bbb42eaa - schermafbeelding-2025-08-24-034132-high.png
- **URL:** https://primary.jwwb.nl/public/h/o/b/temp-nyratlbjkkriqxftlyfy/schermafbeelding-2025-08-24-034132-high.png
- **Size:** 72377 bytes
- **Type:** image/png
- **Link Text:** 
- **Extraction:** ✅ Success

### 0d64aca9 - Gitarre Html.html
- **URL:** https://tel1.jouwweb.nl/_downloads/a1608f86e205b5c50d7aac9fbfc757dc
- **Size:** 79180 bytes
- **Type:** text/html; charset=UTF-8
- **Link Text:** Download
- **Extraction:** ✅ Success

### f8899c2b - image-high-3mtudm.png
- **URL:** https://primary.jwwb.nl/public/h/o/b/temp-nyratlbjkkriqxftlyfy/image-high-3mtudm.png
- **Size:** 245738 bytes
- **Type:** image/png
- **Link Text:** 
- **Extraction:** ✅ Success

### ee655320 - Gitarre Html Visionview Must Be Updated Html.html
- **URL:** https://tel1.jouwweb.nl/_downloads/a04ab7e5ad2830e520ce4a4456d4afa5
- **Size:** 720241 bytes
- **Type:** text/html; charset=UTF-8
- **Link Text:** Download
- **Extraction:** ✅ Success

### 5527cd69 - Tel Geschenk Package All Languages With Cover Zip.zip
- **URL:** https://tel1.jouwweb.nl/_downloads/cdf7ef34db189368dbfe81dafffe2078
- **Size:** 50472 bytes
- **Type:** application/zip
- **Link Text:** Download
- **Extraction:** ✅ Success

### d8b005ad - Documentation Zip.zip
- **URL:** https://tel1.jouwweb.nl/_downloads/ef44d86282e62f36db2d66aeecf1b496
- **Size:** 48767 bytes
- **Type:** application/zip
- **Link Text:** Download
- **Extraction:** ✅ Success

### a5223d8e - Testversion 0001 Gitarre Html Zip.zip
- **URL:** https://tel1.jouwweb.nl/_downloads/11d82b5d247decbe44f53f0b13278ed9
- **Size:** 88863 bytes
- **Type:** application/zip
- **Link Text:** Download
- **Extraction:** ✅ Success

### 2d7af832 - schermafbeelding-2025-08-25-064651-high.png
- **URL:** https://primary.jwwb.nl/public/h/o/b/temp-nyratlbjkkriqxftlyfy/schermafbeelding-2025-08-25-064651-high.png
- **Size:** 101115 bytes
- **Type:** image/png
- **Link Text:** 
- **Extraction:** ✅ Success

### e9d13c30 - Notar Production Instructions 2 Zip.zip
- **URL:** https://tel1.jouwweb.nl/_downloads/de1761d352ff9289ecec2cc7e4a1759d
- **Size:** 37948 bytes
- **Type:** application/zip
- **Link Text:** Download
- **Extraction:** ✅ Success

### c331d4b2 - Digitalnotar Docu Zip 1 Zip.zip
- **URL:** https://tel1.jouwweb.nl/_downloads/45afbfdf4fcafc67a2ca00f4638c1ad3
- **Size:** 141712 bytes
- **Type:** application/zip
- **Link Text:** Download
- **Extraction:** ✅ Success

### 5527cd69 - Tel Geschenk Package All Languages With Cover Zip.zip
- **URL:** https://tel1.jouwweb.nl/_downloads/cdf7ef34db189368dbfe81dafffe2078
- **Size:** 50472 bytes
- **Type:** application/zip
- **Link Text:** Download
- **Extraction:** ✅ Success

### 9db06b57 - Werrkvoorbeeld H 10.docx
- **URL:** https://tel1.jouwweb.nl/_downloads/807f7c4beea346aba09b6a5a719d4695
- **Size:** 5542 bytes
- **Type:** application/vnd.openxmlformats-officedocument.wordprocessingml.document
- **Link Text:** Download
- **Extraction:** ✅ Success

### 2d1ab3fb - university.html
- **URL:** https://digitalnotar.in/university.html
- **Size:** 52983 bytes
- **Type:** text/html
- **Link Text:** APRODUCTIONWORKSSHOPA
- **Extraction:** ✅ Success

### 2d1ab3fb - university.html
- **URL:** https://digitalnotar.in/university.html
- **Size:** 52983 bytes
- **Type:** text/html
- **Link Text:** VOLLVERSION
- **Extraction:** ✅ Success

### 2d1ab3fb - university.html
- **URL:** https://digitalnotar.in/university.html
- **Size:** 52983 bytes
- **Type:** text/html
- **Link Text:** 🎸 TEL Portal - All-In-One für alle Geräte
- **Extraction:** ✅ Success

### 2d1ab3fb - university.html
- **URL:** https://digitalnotar.in/university.html
- **Size:** 52983 bytes
- **Type:** text/html
- **Link Text:** 🎸 TEL Portal - All-In-One für alle Geräte
- **Extraction:** ✅ Success

### 2b24f96d - Psy Ai Complete Doku 2025 Zip.zip
- **URL:** https://tel1.jouwweb.nl/_downloads/990ef2ae57c87c03a5a3a4697f509d9d
- **Size:** 8791 bytes
- **Type:** application/zip
- **Link Text:** Download
- **Extraction:** ✅ Success

### 5006a680 - Tel 1 Pitchdeck 2025 En Pptx.pptx
- **URL:** https://tel1.jouwweb.nl/_downloads/196f28f29d2a98895e6a235156d50634
- **Size:** 37144 bytes
- **Type:** application/vnd.openxmlformats-officedocument.presentationml.presentation
- **Link Text:** Download
- **Extraction:** ✅ Success

### 6caafc79 - Tel 1 Pitchdeck 2025 De En Nl Zip.zip
- **URL:** https://tel1.jouwweb.nl/_downloads/8946b9fdb443f5ec9810fbf459d75f20
- **Size:** 95732 bytes
- **Type:** application/zip
- **Link Text:** Download
- **Extraction:** ✅ Success

### 027094af - Cv R D Tel Html.html
- **URL:** https://tel1.jouwweb.nl/_downloads/64f719ed39ec7ce656424a5a2077e0e1
- **Size:** 195700 bytes
- **Type:** text/html; charset=UTF-8
- **Link Text:** Download
- **Extraction:** ✅ Success

### 5527cd69 - Tel Geschenk Package All Languages With Cover Zip.zip
- **URL:** https://tel1.jouwweb.nl/_downloads/cdf7ef34db189368dbfe81dafffe2078
- **Size:** 50472 bytes
- **Type:** application/zip
- **Link Text:** Download
- **Extraction:** ✅ Success

### d4054e0f - Digitalnotar Docu Zip.zip
- **URL:** https://tel1.jouwweb.nl/_downloads/1bebae439e02f05742717aa43de15227
- **Size:** 141712 bytes
- **Type:** application/zip
- **Link Text:** Download
- **Extraction:** ✅ Success

### 0f5fe54b - Merchandise Pdf.pdf
- **URL:** https://tel1.jouwweb.nl/_downloads/780e862a44e98f773a93facfcff12536
- **Size:** 141621 bytes
- **Type:** application/pdf
- **Link Text:** Download
- **Extraction:** ✅ Success

### 5527cd69 - Tel Geschenk Package All Languages With Cover Zip.zip
- **URL:** https://tel1.jouwweb.nl/_downloads/cdf7ef34db189368dbfe81dafffe2078
- **Size:** 50472 bytes
- **Type:** application/zip
- **Link Text:** Download
- **Extraction:** ✅ Success

### 5527cd69 - Tel Geschenk Package All Languages With Cover Zip.zip
- **URL:** https://tel1.jouwweb.nl/_downloads/cdf7ef34db189368dbfe81dafffe2078
- **Size:** 50472 bytes
- **Type:** application/zip
- **Link Text:** Download
- **Extraction:** ✅ Success

### 9db06b57 - Werrkvoorbeeld H 10.docx
- **URL:** https://tel1.jouwweb.nl/_downloads/807f7c4beea346aba09b6a5a719d4695
- **Size:** 5542 bytes
- **Type:** application/vnd.openxmlformats-officedocument.wordprocessingml.document
- **Link Text:** Download
- **Extraction:** ✅ Success

### 2d1ab3fb - university.html
- **URL:** https://digitalnotar.in/university.html
- **Size:** 52983 bytes
- **Type:** text/html
- **Link Text:** APRODUCTIONWORKSSHOPA
- **Extraction:** ✅ Success

### 2d1ab3fb - university.html
- **URL:** https://digitalnotar.in/university.html
- **Size:** 52983 bytes
- **Type:** text/html
- **Link Text:** VOLLVERSION
- **Extraction:** ✅ Success

### 2d1ab3fb - university.html
- **URL:** https://digitalnotar.in/university.html
- **Size:** 52983 bytes
- **Type:** text/html
- **Link Text:** 🎸 TEL Portal - All-In-One für alle Geräte
- **Extraction:** ✅ Success

### 2d1ab3fb - university.html
- **URL:** https://digitalnotar.in/university.html
- **Size:** 52983 bytes
- **Type:** text/html
- **Link Text:** 🎸 TEL Portal - All-In-One für alle Geräte
- **Extraction:** ✅ Success

### 5527cd69 - Tel Geschenk Package All Languages With Cover Zip.zip
- **URL:** https://tel1.jouwweb.nl/_downloads/cdf7ef34db189368dbfe81dafffe2078
- **Size:** 50472 bytes
- **Type:** application/zip
- **Link Text:** Download
- **Extraction:** ✅ Success

### 9db06b57 - Werrkvoorbeeld H 10.docx
- **URL:** https://tel1.jouwweb.nl/_downloads/807f7c4beea346aba09b6a5a719d4695
- **Size:** 5542 bytes
- **Type:** application/vnd.openxmlformats-officedocument.wordprocessingml.document
- **Link Text:** Download
- **Extraction:** ✅ Success

### 2d1ab3fb - university.html
- **URL:** https://digitalnotar.in/university.html
- **Size:** 52983 bytes
- **Type:** text/html
- **Link Text:** APRODUCTIONWORKSSHOPA
- **Extraction:** ✅ Success

### 2d1ab3fb - university.html
- **URL:** https://digitalnotar.in/university.html
- **Size:** 52983 bytes
- **Type:** text/html
- **Link Text:** VOLLVERSION
- **Extraction:** ✅ Success

### 2d1ab3fb - university.html
- **URL:** https://digitalnotar.in/university.html
- **Size:** 52983 bytes
- **Type:** text/html
- **Link Text:** 🎸 TEL Portal - All-In-One für alle Geräte
- **Extraction:** ✅ Success

### 2d1ab3fb - university.html
- **URL:** https://digitalnotar.in/university.html
- **Size:** 52983 bytes
- **Type:** text/html
- **Link Text:** 🎸 TEL Portal - All-In-One für alle Geräte
- **Extraction:** ✅ Success

### 5527cd69 - Tel Geschenk Package All Languages With Cover Zip.zip
- **URL:** https://tel1.jouwweb.nl/_downloads/cdf7ef34db189368dbfe81dafffe2078
- **Size:** 50472 bytes
- **Type:** application/zip
- **Link Text:** Download
- **Extraction:** ✅ Success

### 9db06b57 - Werrkvoorbeeld H 10.docx
- **URL:** https://tel1.jouwweb.nl/_downloads/807f7c4beea346aba09b6a5a719d4695
- **Size:** 5542 bytes
- **Type:** application/vnd.openxmlformats-officedocument.wordprocessingml.document
- **Link Text:** Download
- **Extraction:** ✅ Success

### 2d1ab3fb - university.html
- **URL:** https://digitalnotar.in/university.html
- **Size:** 52983 bytes
- **Type:** text/html
- **Link Text:** APRODUCTIONWORKSSHOPA
- **Extraction:** ✅ Success

### 2d1ab3fb - university.html
- **URL:** https://digitalnotar.in/university.html
- **Size:** 52983 bytes
- **Type:** text/html
- **Link Text:** VOLLVERSION
- **Extraction:** ✅ Success

### 2d1ab3fb - university.html
- **URL:** https://digitalnotar.in/university.html
- **Size:** 52983 bytes
- **Type:** text/html
- **Link Text:** 🎸 TEL Portal - All-In-One für alle Geräte
- **Extraction:** ✅ Success

### 2d1ab3fb - university.html
- **URL:** https://digitalnotar.in/university.html
- **Size:** 52983 bytes
- **Type:** text/html
- **Link Text:** 🎸 TEL Portal - All-In-One für alle Geräte
- **Extraction:** ✅ Success

### 5527cd69 - Tel Geschenk Package All Languages With Cover Zip.zip
- **URL:** https://tel1.jouwweb.nl/_downloads/cdf7ef34db189368dbfe81dafffe2078
- **Size:** 50472 bytes
- **Type:** application/zip
- **Link Text:** Download
- **Extraction:** ✅ Success

### 9db06b57 - Werrkvoorbeeld H 10.docx
- **URL:** https://tel1.jouwweb.nl/_downloads/807f7c4beea346aba09b6a5a719d4695
- **Size:** 5542 bytes
- **Type:** application/vnd.openxmlformats-officedocument.wordprocessingml.document
- **Link Text:** Download
- **Extraction:** ✅ Success

### 2d1ab3fb - university.html
- **URL:** https://digitalnotar.in/university.html
- **Size:** 52983 bytes
- **Type:** text/html
- **Link Text:** APRODUCTIONWORKSSHOPA
- **Extraction:** ✅ Success

### 2d1ab3fb - university.html
- **URL:** https://digitalnotar.in/university.html
- **Size:** 52983 bytes
- **Type:** text/html
- **Link Text:** VOLLVERSION
- **Extraction:** ✅ Success

### 2d1ab3fb - university.html
- **URL:** https://digitalnotar.in/university.html
- **Size:** 52983 bytes
- **Type:** text/html
- **Link Text:** 🎸 TEL Portal - All-In-One für alle Geräte
- **Extraction:** ✅ Success

### 2d1ab3fb - university.html
- **URL:** https://digitalnotar.in/university.html
- **Size:** 52983 bytes
- **Type:** text/html
- **Link Text:** 🎸 TEL Portal - All-In-One für alle Geräte
- **Extraction:** ✅ Success

### 5527cd69 - Tel Geschenk Package All Languages With Cover Zip.zip
- **URL:** https://tel1.jouwweb.nl/_downloads/cdf7ef34db189368dbfe81dafffe2078
- **Size:** 50472 bytes
- **Type:** application/zip
- **Link Text:** Download
- **Extraction:** ✅ Success

### 9db06b57 - Werrkvoorbeeld H 10.docx
- **URL:** https://tel1.jouwweb.nl/_downloads/807f7c4beea346aba09b6a5a719d4695
- **Size:** 5542 bytes
- **Type:** application/vnd.openxmlformats-officedocument.wordprocessingml.document
- **Link Text:** Download
- **Extraction:** ✅ Success

### 2d1ab3fb - university.html
- **URL:** https://digitalnotar.in/university.html
- **Size:** 52983 bytes
- **Type:** text/html
- **Link Text:** APRODUCTIONWORKSSHOPA
- **Extraction:** ✅ Success

### 2d1ab3fb - university.html
- **URL:** https://digitalnotar.in/university.html
- **Size:** 52983 bytes
- **Type:** text/html
- **Link Text:** VOLLVERSION
- **Extraction:** ✅ Success

### 2d1ab3fb - university.html
- **URL:** https://digitalnotar.in/university.html
- **Size:** 52983 bytes
- **Type:** text/html
- **Link Text:** 🎸 TEL Portal - All-In-One für alle Geräte
- **Extraction:** ✅ Success

### 2d1ab3fb - university.html
- **URL:** https://digitalnotar.in/university.html
- **Size:** 52983 bytes
- **Type:** text/html
- **Link Text:** 🎸 TEL Portal - All-In-One für alle Geräte
- **Extraction:** ✅ Success

### e54155a6 - Ondernemigsplan Pdf.pdf
- **URL:** https://tel1.jouwweb.nl/_downloads/4b113cee411e0255beb125cdb637cef2
- **Size:** 31435 bytes
- **Type:** application/pdf
- **Link Text:** Download
- **Extraction:** ✅ Success

### ac831846 - Financieel Plan Pdf.pdf
- **URL:** https://tel1.jouwweb.nl/_downloads/671fa5e537993cce0ff267c569a9342e
- **Size:** 28705 bytes
- **Type:** application/pdf
- **Link Text:** Download
- **Extraction:** ✅ Success

### 24b6062e - Anderen Pdf.pdf
- **URL:** https://tel1.jouwweb.nl/_downloads/058d13f82f067b0a5b4755b55df104f4
- **Size:** 31549 bytes
- **Type:** application/pdf
- **Link Text:** Download
- **Extraction:** ✅ Success

### 5527cd69 - Tel Geschenk Package All Languages With Cover Zip.zip
- **URL:** https://tel1.jouwweb.nl/_downloads/cdf7ef34db189368dbfe81dafffe2078
- **Size:** 50472 bytes
- **Type:** application/zip
- **Link Text:** Download
- **Extraction:** ✅ Success

### 9db06b57 - Werrkvoorbeeld H 10.docx
- **URL:** https://tel1.jouwweb.nl/_downloads/807f7c4beea346aba09b6a5a719d4695
- **Size:** 5542 bytes
- **Type:** application/vnd.openxmlformats-officedocument.wordprocessingml.document
- **Link Text:** Download
- **Extraction:** ✅ Success

### 2d1ab3fb - university.html
- **URL:** https://digitalnotar.in/university.html
- **Size:** 52983 bytes
- **Type:** text/html
- **Link Text:** APRODUCTIONWORKSSHOPA
- **Extraction:** ✅ Success

### 2d1ab3fb - university.html
- **URL:** https://digitalnotar.in/university.html
- **Size:** 52983 bytes
- **Type:** text/html
- **Link Text:** VOLLVERSION
- **Extraction:** ✅ Success

### 2d1ab3fb - university.html
- **URL:** https://digitalnotar.in/university.html
- **Size:** 52983 bytes
- **Type:** text/html
- **Link Text:** 🎸 TEL Portal - All-In-One für alle Geräte
- **Extraction:** ✅ Success

### 2d1ab3fb - university.html
- **URL:** https://digitalnotar.in/university.html
- **Size:** 52983 bytes
- **Type:** text/html
- **Link Text:** 🎸 TEL Portal - All-In-One für alle Geräte
- **Extraction:** ✅ Success

### d86c45f8 - index.html
- **URL:** https://bunqbank.w3spaces.com/index.html
- **Size:** 55947 bytes
- **Type:** text/html
- **Link Text:** BunqBank
- **Extraction:** ✅ Success

### d86c45f8 - index.html
- **URL:** https://bunqbank.w3spaces.com/index.html
- **Size:** 55947 bytes
- **Type:** text/html
- **Link Text:** BunqBank
- **Extraction:** ✅ Success

### 5527cd69 - Tel Geschenk Package All Languages With Cover Zip.zip
- **URL:** https://tel1.jouwweb.nl/_downloads/cdf7ef34db189368dbfe81dafffe2078
- **Size:** 50472 bytes
- **Type:** application/zip
- **Link Text:** Download
- **Extraction:** ✅ Success

### 9db06b57 - Werrkvoorbeeld H 10.docx
- **URL:** https://tel1.jouwweb.nl/_downloads/807f7c4beea346aba09b6a5a719d4695
- **Size:** 5542 bytes
- **Type:** application/vnd.openxmlformats-officedocument.wordprocessingml.document
- **Link Text:** Download
- **Extraction:** ✅ Success

### 2d1ab3fb - university.html
- **URL:** https://digitalnotar.in/university.html
- **Size:** 52983 bytes
- **Type:** text/html
- **Link Text:** APRODUCTIONWORKSSHOPA
- **Extraction:** ✅ Success

### 2d1ab3fb - university.html
- **URL:** https://digitalnotar.in/university.html
- **Size:** 52983 bytes
- **Type:** text/html
- **Link Text:** VOLLVERSION
- **Extraction:** ✅ Success

### 2d1ab3fb - university.html
- **URL:** https://digitalnotar.in/university.html
- **Size:** 52983 bytes
- **Type:** text/html
- **Link Text:** 🎸 TEL Portal - All-In-One für alle Geräte
- **Extraction:** ✅ Success

### 2d1ab3fb - university.html
- **URL:** https://digitalnotar.in/university.html
- **Size:** 52983 bytes
- **Type:** text/html
- **Link Text:** 🎸 TEL Portal - All-In-One für alle Geräte
- **Extraction:** ✅ Success

### d86c45f8 - index.html
- **URL:** https://bunqbank.w3spaces.com/index.html
- **Size:** 55947 bytes
- **Type:** text/html
- **Link Text:** BunqBank
- **Extraction:** ✅ Success

### 6416507e - tel1nl.html
- **URL:** https://bunqbank.w3spaces.com/tel1nl.html
- **Size:** 55947 bytes
- **Type:** text/html
- **Link Text:** DEMO
- **Extraction:** ✅ Success

### 5527cd69 - Tel Geschenk Package All Languages With Cover Zip.zip
- **URL:** https://tel1.jouwweb.nl/_downloads/cdf7ef34db189368dbfe81dafffe2078
- **Size:** 50472 bytes
- **Type:** application/zip
- **Link Text:** Download
- **Extraction:** ✅ Success

### 9db06b57 - Werrkvoorbeeld H 10.docx
- **URL:** https://tel1.jouwweb.nl/_downloads/807f7c4beea346aba09b6a5a719d4695
- **Size:** 5542 bytes
- **Type:** application/vnd.openxmlformats-officedocument.wordprocessingml.document
- **Link Text:** Download
- **Extraction:** ✅ Success

### 2d1ab3fb - university.html
- **URL:** https://digitalnotar.in/university.html
- **Size:** 52983 bytes
- **Type:** text/html
- **Link Text:** APRODUCTIONWORKSSHOPA
- **Extraction:** ✅ Success

### 2d1ab3fb - university.html
- **URL:** https://digitalnotar.in/university.html
- **Size:** 52983 bytes
- **Type:** text/html
- **Link Text:** VOLLVERSION
- **Extraction:** ✅ Success

### 2d1ab3fb - university.html
- **URL:** https://digitalnotar.in/university.html
- **Size:** 52983 bytes
- **Type:** text/html
- **Link Text:** 🎸 TEL Portal - All-In-One für alle Geräte
- **Extraction:** ✅ Success

### 2d1ab3fb - university.html
- **URL:** https://digitalnotar.in/university.html
- **Size:** 52983 bytes
- **Type:** text/html
- **Link Text:** 🎸 TEL Portal - All-In-One für alle Geräte
- **Extraction:** ✅ Success

### d86c45f8 - index.html
- **URL:** https://bunqbank.w3spaces.com/index.html
- **Size:** 55947 bytes
- **Type:** text/html
- **Link Text:** BunqBank
- **Extraction:** ✅ Success

### 5527cd69 - Tel Geschenk Package All Languages With Cover Zip.zip
- **URL:** https://tel1.jouwweb.nl/_downloads/cdf7ef34db189368dbfe81dafffe2078
- **Size:** 50472 bytes
- **Type:** application/zip
- **Link Text:** Download
- **Extraction:** ✅ Success

### 9db06b57 - Werrkvoorbeeld H 10.docx
- **URL:** https://tel1.jouwweb.nl/_downloads/807f7c4beea346aba09b6a5a719d4695
- **Size:** 5542 bytes
- **Type:** application/vnd.openxmlformats-officedocument.wordprocessingml.document
- **Link Text:** Download
- **Extraction:** ✅ Success

### 2d1ab3fb - university.html
- **URL:** https://digitalnotar.in/university.html
- **Size:** 52983 bytes
- **Type:** text/html
- **Link Text:** APRODUCTIONWORKSSHOPA
- **Extraction:** ✅ Success

### 2d1ab3fb - university.html
- **URL:** https://digitalnotar.in/university.html
- **Size:** 52983 bytes
- **Type:** text/html
- **Link Text:** VOLLVERSION
- **Extraction:** ✅ Success

### 2d1ab3fb - university.html
- **URL:** https://digitalnotar.in/university.html
- **Size:** 52983 bytes
- **Type:** text/html
- **Link Text:** 🎸 TEL Portal - All-In-One für alle Geräte
- **Extraction:** ✅ Success

### 2d1ab3fb - university.html
- **URL:** https://digitalnotar.in/university.html
- **Size:** 52983 bytes
- **Type:** text/html
- **Link Text:** 🎸 TEL Portal - All-In-One für alle Geräte
- **Extraction:** ✅ Success

### d86c45f8 - index.html
- **URL:** https://bunqbank.w3spaces.com/index.html
- **Size:** 55947 bytes
- **Type:** text/html
- **Link Text:** BunqBank
- **Extraction:** ✅ Success

### 5527cd69 - Tel Geschenk Package All Languages With Cover Zip.zip
- **URL:** https://tel1.jouwweb.nl/_downloads/cdf7ef34db189368dbfe81dafffe2078
- **Size:** 50472 bytes
- **Type:** application/zip
- **Link Text:** Download
- **Extraction:** ✅ Success

### 9db06b57 - Werrkvoorbeeld H 10.docx
- **URL:** https://tel1.jouwweb.nl/_downloads/807f7c4beea346aba09b6a5a719d4695
- **Size:** 5542 bytes
- **Type:** application/vnd.openxmlformats-officedocument.wordprocessingml.document
- **Link Text:** Download
- **Extraction:** ✅ Success

### 2d1ab3fb - university.html
- **URL:** https://digitalnotar.in/university.html
- **Size:** 52983 bytes
- **Type:** text/html
- **Link Text:** APRODUCTIONWORKSSHOPA
- **Extraction:** ✅ Success

### 2d1ab3fb - university.html
- **URL:** https://digitalnotar.in/university.html
- **Size:** 52983 bytes
- **Type:** text/html
- **Link Text:** VOLLVERSION
- **Extraction:** ✅ Success

### 2d1ab3fb - university.html
- **URL:** https://digitalnotar.in/university.html
- **Size:** 52983 bytes
- **Type:** text/html
- **Link Text:** 🎸 TEL Portal - All-In-One für alle Geräte
- **Extraction:** ✅ Success

### 2d1ab3fb - university.html
- **URL:** https://digitalnotar.in/university.html
- **Size:** 52983 bytes
- **Type:** text/html
- **Link Text:** 🎸 TEL Portal - All-In-One für alle Geräte
- **Extraction:** ✅ Success

### d86c45f8 - index.html
- **URL:** https://bunqbank.w3spaces.com/index.html
- **Size:** 55947 bytes
- **Type:** text/html
- **Link Text:** BunqBank
- **Extraction:** ✅ Success

### 1ee73275 - Schuldenvrij.zip
- **URL:** https://tel1.jouwweb.nl/_downloads/31af6a83e01ec58eaaeb0c2048eb27a9
- **Size:** 480931 bytes
- **Type:** application/zip
- **Link Text:** Download
- **Extraction:** ✅ Success

### 5527cd69 - Tel Geschenk Package All Languages With Cover Zip.zip
- **URL:** https://tel1.jouwweb.nl/_downloads/cdf7ef34db189368dbfe81dafffe2078
- **Size:** 50472 bytes
- **Type:** application/zip
- **Link Text:** Download
- **Extraction:** ✅ Success

### 9db06b57 - Werrkvoorbeeld H 10.docx
- **URL:** https://tel1.jouwweb.nl/_downloads/807f7c4beea346aba09b6a5a719d4695
- **Size:** 5542 bytes
- **Type:** application/vnd.openxmlformats-officedocument.wordprocessingml.document
- **Link Text:** Download
- **Extraction:** ✅ Success

### 2d1ab3fb - university.html
- **URL:** https://digitalnotar.in/university.html
- **Size:** 52983 bytes
- **Type:** text/html
- **Link Text:** APRODUCTIONWORKSSHOPA
- **Extraction:** ✅ Success

### 2d1ab3fb - university.html
- **URL:** https://digitalnotar.in/university.html
- **Size:** 52983 bytes
- **Type:** text/html
- **Link Text:** VOLLVERSION
- **Extraction:** ✅ Success

### 2d1ab3fb - university.html
- **URL:** https://digitalnotar.in/university.html
- **Size:** 52983 bytes
- **Type:** text/html
- **Link Text:** 🎸 TEL Portal - All-In-One für alle Geräte
- **Extraction:** ✅ Success

### 2d1ab3fb - university.html
- **URL:** https://digitalnotar.in/university.html
- **Size:** 52983 bytes
- **Type:** text/html
- **Link Text:** 🎸 TEL Portal - All-In-One für alle Geräte
- **Extraction:** ✅ Success

### d86c45f8 - index.html
- **URL:** https://bunqbank.w3spaces.com/index.html
- **Size:** 55947 bytes
- **Type:** text/html
- **Link Text:** BunqBank
- **Extraction:** ✅ Success

### f9ba2504 - download_f9ba2504.bin
- **URL:** https://audiomack.com/telcotelekom/likes
- **Size:** 179503 bytes
- **Type:** text/html; charset=utf-8
- **Link Text:** https://audiomack.com/telcotelekom/likes
- **Extraction:** ✅ Success

### 824e56fd - henne-oder-ei-was-war-zuerst-da-102.html
- **URL:** https://www.swr.de/wissen/1000-antworten/henne-oder-ei-was-war-zuerst-da-102.html
- **Size:** 254713 bytes
- **Type:** text/html;charset=UTF-8
- **Link Text:** Also, das Ei war zuerst da!
- **Extraction:** ✅ Success

### 0a2e7017 - download_0a2e7017.bin
- **URL:** https://1drv.ms/u/s!AnHm2D0uH9mOgZ8H-Ly8wjKLS7HmTg?e=HlzQow
- **Size:** 321002 bytes
- **Type:** text/html; charset=utf-8
- **Link Text:** ALBUMDOWNLOAD
- **Extraction:** ✅ Success

### 5527cd69 - Tel Geschenk Package All Languages With Cover Zip.zip
- **URL:** https://tel1.jouwweb.nl/_downloads/cdf7ef34db189368dbfe81dafffe2078
- **Size:** 50472 bytes
- **Type:** application/zip
- **Link Text:** Download
- **Extraction:** ✅ Success

### 9db06b57 - Werrkvoorbeeld H 10.docx
- **URL:** https://tel1.jouwweb.nl/_downloads/807f7c4beea346aba09b6a5a719d4695
- **Size:** 5542 bytes
- **Type:** application/vnd.openxmlformats-officedocument.wordprocessingml.document
- **Link Text:** Download
- **Extraction:** ✅ Success

### 2d1ab3fb - university.html
- **URL:** https://digitalnotar.in/university.html
- **Size:** 52983 bytes
- **Type:** text/html
- **Link Text:** APRODUCTIONWORKSSHOPA
- **Extraction:** ✅ Success

### 2d1ab3fb - university.html
- **URL:** https://digitalnotar.in/university.html
- **Size:** 52983 bytes
- **Type:** text/html
- **Link Text:** VOLLVERSION
- **Extraction:** ✅ Success

### 2d1ab3fb - university.html
- **URL:** https://digitalnotar.in/university.html
- **Size:** 52983 bytes
- **Type:** text/html
- **Link Text:** 🎸 TEL Portal - All-In-One für alle Geräte
- **Extraction:** ✅ Success

### 2d1ab3fb - university.html
- **URL:** https://digitalnotar.in/university.html
- **Size:** 52983 bytes
- **Type:** text/html
- **Link Text:** 🎸 TEL Portal - All-In-One für alle Geräte
- **Extraction:** ✅ Success

### d86c45f8 - index.html
- **URL:** https://bunqbank.w3spaces.com/index.html
- **Size:** 55947 bytes
- **Type:** text/html
- **Link Text:** BunqBank
- **Extraction:** ✅ Success

### 5e53d0f0 - schermafbeelding-2025-10-13-133756-high.png
- **URL:** https://primary.jwwb.nl/public/h/o/b/temp-nyratlbjkkriqxftlyfy/schermafbeelding-2025-10-13-133756-high.png
- **Size:** 508193 bytes
- **Type:** image/png
- **Link Text:** 
- **Extraction:** ✅ Success

### ae01b4ac - Psy Ai Complete Doku 2025 Zip.zip
- **URL:** https://tel1.jouwweb.nl/_downloads/faeb2881d83c94dda38eff2523d7f623
- **Size:** 8791 bytes
- **Type:** application/zip
- **Link Text:** Download
- **Extraction:** ✅ Success

### 5527cd69 - Tel Geschenk Package All Languages With Cover Zip.zip
- **URL:** https://tel1.jouwweb.nl/_downloads/cdf7ef34db189368dbfe81dafffe2078
- **Size:** 50472 bytes
- **Type:** application/zip
- **Link Text:** Download
- **Extraction:** ✅ Success

### 5527cd69 - Tel Geschenk Package All Languages With Cover Zip.zip
- **URL:** https://tel1.jouwweb.nl/_downloads/cdf7ef34db189368dbfe81dafffe2078
- **Size:** 50472 bytes
- **Type:** application/zip
- **Link Text:** Download
- **Extraction:** ✅ Success

### d6da79f7 - Cms System Rdtel Zip.zip
- **URL:** https://tel1.jouwweb.nl/_downloads/b3940875a1d0e51affda146f718b8003
- **Size:** 36679 bytes
- **Type:** application/zip
- **Link Text:** Download
- **Extraction:** ✅ Success

### d4054e0f - Digitalnotar Docu Zip.zip
- **URL:** https://tel1.jouwweb.nl/_downloads/1bebae439e02f05742717aa43de15227
- **Size:** 141712 bytes
- **Type:** application/zip
- **Link Text:** Download
- **Extraction:** ✅ Success

### 12abc123 - index.html
- **URL:** http://www.hahn-borkum.de/index.html
- **Size:** 1870 bytes
- **Type:** text/html
- **Link Text:** 
- **Extraction:** ✅ Success

### 4e269417 - Miniquiz Zip.zip
- **URL:** https://tel1.jouwweb.nl/_downloads/31dbfeea3723d5d20862d4638adb6363
- **Size:** 10232014 bytes
- **Type:** application/zip
- **Link Text:** Download
- **Extraction:** ✅ Success

### eead5928 - Telcotelekom Tel 1 Nl Mp 3.mp3
- **URL:** https://tel1.jouwweb.nl/_downloads/c126b67ff65d0dbfe3d76f98f3e717b2
- **Size:** 3973440 bytes
- **Type:** audio/mpeg
- **Link Text:** Download
- **Extraction:** ✅ Success

### cca65949 - Tel 1 Nl Liebe Zielgruppe Pdf.pdf
- **URL:** https://tel1.jouwweb.nl/_downloads/1b09348c88a4bff49074d6acf3b17113
- **Size:** 394574 bytes
- **Type:** application/pdf
- **Link Text:** Download
- **Extraction:** ✅ Success

### 8765c03a - The Journey Of Two Sperm Cells Pdf.pdf
- **URL:** https://tel1.jouwweb.nl/_downloads/75c040d5f2762ae3d94a0db21091aee0
- **Size:** 32836 bytes
- **Type:** application/pdf
- **Link Text:** Download
- **Extraction:** ✅ Success

### 9ad6a125 - Der Ursprung Des Nichts Pdf.pdf
- **URL:** https://tel1.jouwweb.nl/_downloads/90da7a00a8074a02325c5856f02d3ce2
- **Size:** 46133 bytes
- **Type:** application/pdf
- **Link Text:** Download
- **Extraction:** ✅ Success

### a4520919 - De Reis Van Twee Spermacellen Pdf.pdf
- **URL:** https://tel1.jouwweb.nl/_downloads/4a33b4a9433cb97bccffe2950468f0cd
- **Size:** 32971 bytes
- **Type:** application/pdf
- **Link Text:** Download
- **Extraction:** ✅ Success

### afdb804a - Trump Mp 4.mp4
- **URL:** https://tel1.jouwweb.nl/_downloads/aece81e49165122cf6adfcb797c25e2c
- **Size:** 6399815 bytes
- **Type:** video/mp4
- **Link Text:** Download
- **Extraction:** ✅ Success

### e32b41b8 - Bo TNL OPDRACHT AAN EU VOOR NU Wor K.pdf
- **URL:** https://tel1.jouwweb.nl/_downloads/af1d4c5e0685a1d88e73984cd2eff330
- **Size:** 41957 bytes
- **Type:** application/pdf
- **Link Text:** Download
- **Extraction:** ✅ Success

### ffe2d557 - Peace Pdf.pdf
- **URL:** https://tel1.jouwweb.nl/_downloads/b66dfc3d615e390a723e6a61a582e4c6
- **Size:** 83097 bytes
- **Type:** application/pdf
- **Link Text:** Download
- **Extraction:** ✅ Success

### 49659737 - De Ster Van Morgen Pdf.pdf
- **URL:** https://tel1.jouwweb.nl/_downloads/b5ee6e431f659e0c28e4c1eae4394df5
- **Size:** 29595 bytes
- **Type:** application/pdf
- **Link Text:** Download
- **Extraction:** ✅ Success

### a485a6a9 - Een Kerstwonder Pdf.pdf
- **URL:** https://tel1.jouwweb.nl/_downloads/621c98e524dc8e12ca5f938ac6daf225
- **Size:** 27750 bytes
- **Type:** application/pdf
- **Link Text:** Download
- **Extraction:** ✅ Success

### d10b7f46 - noten-high.jpg
- **URL:** https://primary.jwwb.nl/public/h/o/b/temp-nyratlbjkkriqxftlyfy/noten-high.jpg
- **Size:** 100783 bytes
- **Type:** image/jpeg
- **Link Text:** 
- **Extraction:** ✅ Success

### 84829f63 - Noten Jpg.jpg
- **URL:** https://tel1.jouwweb.nl/_downloads/aadbe49aef5a4543a4ba05da30a08a54
- **Size:** 219130 bytes
- **Type:** image/jpeg
- **Link Text:** Download
- **Extraction:** ✅ Success

### 5527cd69 - Tel Geschenk Package All Languages With Cover Zip.zip
- **URL:** https://tel1.jouwweb.nl/_downloads/cdf7ef34db189368dbfe81dafffe2078
- **Size:** 50472 bytes
- **Type:** application/zip
- **Link Text:** Download
- **Extraction:** ✅ Success

### 9db06b57 - Werrkvoorbeeld H 10.docx
- **URL:** https://tel1.jouwweb.nl/_downloads/807f7c4beea346aba09b6a5a719d4695
- **Size:** 5542 bytes
- **Type:** application/vnd.openxmlformats-officedocument.wordprocessingml.document
- **Link Text:** Download
- **Extraction:** ✅ Success

### 2d1ab3fb - university.html
- **URL:** https://digitalnotar.in/university.html
- **Size:** 52983 bytes
- **Type:** text/html
- **Link Text:** APRODUCTIONWORKSSHOPA
- **Extraction:** ✅ Success

### 2d1ab3fb - university.html
- **URL:** https://digitalnotar.in/university.html
- **Size:** 52983 bytes
- **Type:** text/html
- **Link Text:** VOLLVERSION
- **Extraction:** ✅ Success

### 2d1ab3fb - university.html
- **URL:** https://digitalnotar.in/university.html
- **Size:** 52983 bytes
- **Type:** text/html
- **Link Text:** 🎸 TEL Portal - All-In-One für alle Geräte
- **Extraction:** ✅ Success

### 2d1ab3fb - university.html
- **URL:** https://digitalnotar.in/university.html
- **Size:** 52983 bytes
- **Type:** text/html
- **Link Text:** 🎸 TEL Portal - All-In-One für alle Geräte
- **Extraction:** ✅ Success

