# Program Analysis Report - a068075a

**Original File:** Tel 1 Angebotskatalog Aktualisiert Print Html.html
**Source URL:** https://tel1.jouwweb.nl/_downloads/3fe9cf7a9645ad930a45ea1c339428c3
**File Size:** 12356 bytes
**Content Type:** text/html; charset=UTF-8

## File Analysis

### metadata.json
- **Type:** json
- **Size:** 112 bytes
- **Extension:** .json
- **error:** name 'v' is not defined

### Tel 1 Angebotskatalog Aktualisiert Print Html.html
- **Type:** html
- **Size:** 12356 bytes
- **Extension:** .html
- **title:** TEL & Gentlyoverdone – Angebotskatalog (aktualisiert)
- **headings:** ['TEL & Gentlyoverdone – Angebotskatalog Stand: August 2025', 'Überblick', 'Marke & Domain: TEL1.nl', 'Servicesoftware (Spezialbereich)', 'Musik: Veröffentlichungen 2024–2025 (Auswahl)', 'Merchandise & EXPO', 'Community & Soziales (RIBW / H10)', 'Kooperationen, Ideen & Proposals', 'Technische Architektur (Website/Plattformen)', 'Didaktische Module (Lehramt/Technik/Wissenschaft)', 'M1 – Musik & Gesellschaft (Sek.\u202fI/II)', 'M2 – Digitale Musikproduktion & Notation', 'M3 – KI & Handel: Chancen/Risiken', 'M4 – Nachhaltigkeit & Konsum (TEL GreenChoice)', 'Rechtliche Hinweise & Lizenzen', 'Kontakt (lt. Website)', 'Quellen (Auswahl)']
- **links:** [{'text': 'Start', 'href': '#top'}, {'text': 'Überblick', 'href': '#ueberblick'}, {'text': 'Marke & Domain', 'href': '#marke'}, {'text': 'Servicesoftware', 'href': '#software'}, {'text': 'Musik', 'href': '#musik'}, {'text': 'Merch & EXPO', 'href': '#merch'}, {'text': 'Community', 'href': '#community'}, {'text': 'Kooperationen', 'href': '#koops'}, {'text': 'Technik', 'href': '#technik'}, {'text': 'Didaktik', 'href': '#didaktik'}, {'text': 'Recht', 'href': '#recht'}, {'text': 'Kontakt', 'href': '#kontakt'}, {'text': 'Quellen', 'href': '#quellen'}, {'text': 'TEL1.nl', 'href': 'https://tel1.jouwweb.nl/'}, {'text': 'Servicesoftware', 'href': 'https://tel1.jouwweb.nl/servicesoftware'}, {'text': '', 'href': 'https://open.spotify.com/'}, {'text': '', 'href': 'https://www.qobuz.com/'}, {'text': '', 'href': 'https://www.amazon.com/music'}, {'text': '', 'href': 'https://audiomack.com/'}, {'text': 'TEL1 Musicart (T‑POP)', 'href': 'https://tel1.tpopsite.com'}, {'text': 'GentlyOverdone@Outlook.com', 'href': 'mailto:GentlyOverdone@Outlook.com'}, {'text': '+31 6 1380 3782', 'href': 'tel:+31613803782'}, {'text': 'tel1.boards.net', 'href': 'https://tel1.boards.net'}, {'text': 'TEL1 – Startseite', 'href': 'https://tel1.jouwweb.nl/'}, {'text': 'About', 'href': 'https://tel1.jouwweb.nl/about'}, {'text': 'H10', 'href': 'https://tel1.jouwweb.nl/h10'}, {'text': 'Meer RIBW', 'href': 'https://tel1.jouwweb.nl/meer-ribw'}, {'text': 'Empower', 'href': 'https://tel1.jouwweb.nl/empower'}, {'text': 'Contact', 'href': 'https://tel1.jouwweb.nl/contact'}, {'text': 'Servicesoftware', 'href': 'https://tel1.jouwweb.nl/servicesoftware'}, {'text': 'EXPO', 'href': 'https://tel1.jouwweb.nl/expo'}, {'text': 'Zurück nach oben', 'href': '#top'}]
- **images:** ['https://upload.wikimedia.org/wikipedia/commons/1/19/Spotify_logo_without_text.svg', 'https://upload.wikimedia.org/wikipedia/commons/6/60/Qobuz_logo.png', 'https://upload.wikimedia.org/wikipedia/commons/1/1c/Amazon_Music_logo.svg', 'https://upload.wikimedia.org/wikipedia/commons/0/0b/Audiomack_logo.svg']
- **scripts:** []
- **forms:** 0
- **content_length:** 12091

