# Program Analysis Report - ef376cdd

**Original File:** Cursor Ontwikkelingsgids Nederlands 1 Pdf.pdf
**Source URL:** https://tel1.jouwweb.nl/_downloads/3bfbeee4545423bf45270eacda4b6ab7
**File Size:** 317910 bytes
**Content Type:** application/pdf

## File Analysis

### Cursor Ontwikkelingsgids Nederlands 1 Pdf.pdf
- **Type:** unknown
- **Size:** 317910 bytes
- **Extension:** .pdf

### extracted_text.txt
- **Type:** text
- **Size:** 25772 bytes
- **Extension:** .txt
- **content_length:** 24793
- **lines:** 647
- **words:** 3437
- **preview:** 🚀 CURSOR.COM ONTWIKKELINGSGIDS -
NEDERLANDS
“Raymond Demitrio T el” Bouwpakket-Rapport voor AI-
ondersteunde App-ontwikkeling
Van Nul naar  Held - Zonder  voorkennis naar  professionele app
📋 INHOUDSOPGA VE
1. 🎯 Inleiding - Hoe een kind leert programmeren
2. 🧠 AI-Psychologie opbouwen - Uw digitale assistent
3. ⚙ Cursor .com Setup - Eerste stappen
4. 🏗 App-ontwikkeling Stap-voor -Stap
5. 🔄 ROI-Routines & Automatisering
6. 📱 Visueel programmeren zonder kennis
7. 🎨 Psychologische UI/UX Patronen
8. ...

