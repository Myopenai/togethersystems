# Program Analysis Report - d86c45f8

**Original File:** index.html
**Source URL:** https://bunqbank.w3spaces.com/index.html
**File Size:** 55947 bytes
**Content Type:** text/html

## File Analysis

### index.html
- **Type:** html
- **Size:** 1870 bytes
- **Extension:** .html
- **title:** Borkum grüsst den Rest der Welt !
- **headings:** ['Achtung!']
- **links:** [{'text': 'Netscape', 'href': 'http://www.netscape.com'}, {'text': 'MS Internet Explorer', 'href': 'http://www.microsoft.de'}]
- **images:** []
- **scripts:** []
- **forms:** 0
- **content_length:** 1866

### metadata.json
- **Type:** json
- **Size:** 71 bytes
- **Extension:** .json
- **error:** name 'v' is not defined

