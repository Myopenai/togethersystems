# Program Analysis Report - 5006a680

**Original File:** Tel 1 Pitchdeck 2025 En Pptx.pptx
**Source URL:** https://tel1.jouwweb.nl/_downloads/196f28f29d2a98895e6a235156d50634
**File Size:** 37144 bytes
**Content Type:** application/vnd.openxmlformats-officedocument.presentationml.presentation

## File Analysis

### metadata.json
- **Type:** json
- **Size:** 95 bytes
- **Extension:** .json
- **error:** name 'v' is not defined

### Tel 1 Pitchdeck 2025 En Pptx.pptx
- **Type:** unknown
- **Size:** 37144 bytes
- **Extension:** .pptx

