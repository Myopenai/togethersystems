# Program Analysis Report - a485a6a9

**Original File:** Een Kerstwonder Pdf.pdf
**Source URL:** https://tel1.jouwweb.nl/_downloads/621c98e524dc8e12ca5f938ac6daf225
**File Size:** 27750 bytes
**Content Type:** application/pdf

## File Analysis

### Een Kerstwonder Pdf.pdf
- **Type:** unknown
- **Size:** 27750 bytes
- **Extension:** .pdf

### extracted_text.txt
- **Type:** text
- **Size:** 3555 bytes
- **Extension:** .txt
- **content_length:** 3473
- **lines:** 41
- **words:** 593
- **preview:** ### **Een kerstwonder door kinderogen - toen en nu**
Er was eens een jongen genaamd Elias die op een ijzige decemberavond in zijn kleine kamer zat. Hij 
bladerde door een oud boek dat zijn grootmoeder hem had gegeven: een bijbel, vergeeld en vol verhalen uit 
een andere tijd. Maar Elias was een kind van het heden. Zijn mobiele telefoon lag naast hem, en het 
flikkerende nieuws over oorlogen, klimaatverandering en onrecht zette hem vaak aan het denken.
‘Waarom’, vroeg hij zich af, ‘is de wereld z...

