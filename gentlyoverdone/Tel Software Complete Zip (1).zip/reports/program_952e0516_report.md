# Program Analysis Report - 952e0516

**Original File:** Gitarre Html 1 Html.html
**Source URL:** https://tel1.jouwweb.nl/_downloads/00869c1ca30df16238fca9fedf5ef714
**File Size:** 79180 bytes
**Content Type:** text/html; charset=UTF-8

## File Analysis

### Gitarre Html 1 Html.html
- **Type:** html
- **Size:** 79180 bytes
- **Extension:** .html
- **title:** Gitarren‑Akkord‑Transposer – ohne Build
- **headings:** ['🎸 Gitarren‑Akkord‑Transposer (Single‑File)', '🎵 Häufige Akkordfolgen', 'Griffbilder', 'ASCII‑TAB Vorschau', '🎼 Musiknotation', '🎵 Producer & Kontakt', '🎧 Gentlyoverdone auf Spotify', '🎧 Gentlyoverdonelivestudio Album', '📺 Gentlyoverdone YouTube Playlist', '📺 TEL & Gentlyoverdone Live Studio', 'Neues Projekt erstellen', 'Projekte laden', 'Noten eingeben', 'Live-Noten-Anzeige', 'Multimedia-Player']
- **links:** [{'text': 'gentlyoverdone@outlook.com', 'href': 'mailto:gentlyoverdone@outlook.com'}, {'text': 'www.tel1.nl', 'href': 'https://tel1.jouwweb.nl/contact'}, {'text': 'www.gentlyoverdone.com', 'href': 'https://www.gentlyoverdone.com'}, {'text': '🎵 Magnitudo Musica Mundo unterstützen', 'href': 'https://www.gofundme.com/f/magnitudo?utm_campaign=unknown&utm_medium=referral&utm_source=widget'}]
- **images:** []
- **scripts:** ['https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js', 'https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.29/jspdf.plugin.autotable.min.js']
- **forms:** 0
- **content_length:** 78748

### metadata.json
- **Type:** json
- **Size:** 86 bytes
- **Extension:** .json
- **error:** name 'v' is not defined

