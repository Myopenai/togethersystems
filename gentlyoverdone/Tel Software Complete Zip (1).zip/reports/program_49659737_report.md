# Program Analysis Report - 49659737

**Original File:** De Ster Van Morgen Pdf.pdf
**Source URL:** https://tel1.jouwweb.nl/_downloads/b5ee6e431f659e0c28e4c1eae4394df5
**File Size:** 29595 bytes
**Content Type:** application/pdf

## File Analysis

### De Ster Van Morgen Pdf.pdf
- **Type:** unknown
- **Size:** 29595 bytes
- **Extension:** .pdf

### extracted_text.txt
- **Type:** text
- **Size:** 4324 bytes
- **Extension:** .txt
- **content_length:** 4233
- **lines:** 44
- **words:** 717
- **preview:** ### **De Ster van Morgen – Een kerstverhaal door de ogen van een kind**
De decemberwind danste door de smalle straatjes van een oude stad. De ramen gloeiden warm terwijl sneeuwvlokken als delicate 
veren uit de lucht vielen. Middenin dit alles stond Lina, een meisje met grote, vragende ogen die vaak in gedachten verzonken waren.
Maar vandaag was ze niet alleen: de wereld zelf leek met haar mee te fluisteren.
‘Waarom’, vroeg ze aan de glinsterende nachtelijke hemel, ‘lijkt alles wat ooit heilig w...

