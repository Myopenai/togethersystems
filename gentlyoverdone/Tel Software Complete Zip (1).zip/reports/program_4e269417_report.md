# Program Analysis Report - 4e269417

**Original File:** Miniquiz Zip.zip
**Source URL:** https://tel1.jouwweb.nl/_downloads/31dbfeea3723d5d20862d4638adb6363
**File Size:** 10232014 bytes
**Content Type:** application/zip

## File Analysis

### Mini-Quiz-Installer.exe
- **Type:** unknown
- **Size:** 10243491 bytes
- **Extension:** .exe

