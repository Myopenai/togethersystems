# Program Analysis Report - 2d1ab3fb

**Original File:** university.html
**Source URL:** https://digitalnotar.in/university.html
**File Size:** 52983 bytes
**Content Type:** text/html

## File Analysis

### metadata.json
- **Type:** json
- **Size:** 77 bytes
- **Extension:** .json
- **error:** name 'v' is not defined

### university.html
- **Type:** html
- **Size:** 52983 bytes
- **Extension:** .html
- **title:** DIGITALNOTAR.IN - Alle Portale | Raymond Demitrio Tel
- **headings:** ['🏛️ DIGITALNOTAR.IN', '⚖️ Gesetzeskonforme Zertifizierung & AI Maintain', '🔍 Erweiterte Navigation & Suche', 'Globale Suche', 'Erweiterter Index', '🛡️ Maintain-AI-System', 'Eternal Maintain Core', 'Self-Healing Engine', '📱 Kommunikation & WebRTC Portale', 'Konferenz Portal', 'PeerLink Portal', 'JamSession Portal', 'PeerCam & Live Chat', '🔗 Verbindung & QR Portale', 'QR Generator', 'QR Scanner', 'Connection Hub', 'Device Manager', 'NFC Hub', '🏗️ System & Admin Portale', 'Admin Dashboard', 'Server Dashboard', 'Monitoring Portal', 'TURN Server', 'Redis Viewer', 'Live Test Suite', '🧠 AI & Automation Portale', 'MAIPS Explorer', 'Visual Scientific Monitor', 'Integrated System Monitor', '🚀 Space & Research Portale', 'Space Watcher', 'Real Space APIs', 'Space Watcher System', '🏦 Business & Banking Portale', 'Banking API Explorer', '🎵 Media & Producer Portale', 'Media Gallery', 'File Manager', 'Stage Toolbox', '🏛️ Notariat & Legal Portale', 'Digitalnotariat Portal', 'Gitarre HTML Notariat', 'NASSIS Modul', '🔧 Development & Tools Portale', 'Build Suite', 'WebRTC Test Harness', 'Techniques Management', 'Provider Management', '🧩 Erweiterte & Versteckte Tools', 'Feature Flag Console', 'Zero‑Trust Policy Center', 'Maintainé AI Control', 'Telemetry Studio']
- **links:** [{'text': 'Öffnen', 'href': 'apps/feature-flags.html'}, {'text': 'Öffnen', 'href': 'apps/maintaine-ai.html'}, {'text': 'Versionierter Bericht', 'href': '../guitar-test.html'}, {'text': 'Versionierter Bericht', 'href': '../DIGITALNOTAR-ANALYSE-FUER-SPAETER-V2025.09.18.md'}, {'text': 'Globale Suche öffnen', 'href': 'apps/global-search.html'}, {'text': 'Direkt öffnen', 'href': 'apps/extended-index.html'}, {'text': 'Direkt öffnen', 'href': 'apps/eternal-maintain-core.html'}, {'text': 'Direkt öffnen', 'href': 'apps/self-healing-engine.html'}, {'text': 'Direkt öffnen', 'href': 'apps/conference-full.html'}, {'text': 'Direkt öffnen', 'href': 'apps/peerlink-full.html'}, {'text': 'Direkt öffnen', 'href': 'apps/jamssession.html'}, {'text': 'Direkt öffnen', 'href': 'apps/peer-cam-chat.html'}, {'text': 'Direkt öffnen', 'href': 'apps/qr-generator.html'}, {'text': 'Direkt öffnen', 'href': 'apps/qr-scanner.html'}, {'text': 'Direkt öffnen', 'href': 'apps/connection-hub.html'}, {'text': 'Direkt öffnen', 'href': 'apps/device-manager.html'}, {'text': 'Direkt öffnen', 'href': 'apps/nfc-hub.html'}, {'text': 'Direkt öffnen', 'href': 'apps/admin-dashboard.html'}, {'text': 'Direkt öffnen', 'href': 'apps/server-dashboard.html'}, {'text': 'Direkt öffnen', 'href': 'apps/monitor.html'}, {'text': 'Direkt öffnen', 'href': 'apps/turn-status.html'}, {'text': 'Direkt öffnen', 'href': 'apps/redis-viewer.html'}, {'text': 'Direkt öffnen', 'href': 'apps/live-test-suite.html'}, {'text': 'Direkt öffnen', 'href': 'apps/maips-explorer.html'}, {'text': 'Direkt öffnen', 'href': 'apps/visual-scientific-monitor.html'}, {'text': 'Direkt öffnen', 'href': 'apps/integrated-system-monitor.html'}, {'text': 'Direkt öffnen', 'href': 'apps/space-watcher.html'}, {'text': 'Direkt öffnen', 'href': 'apps/real-space-apis.html'}, {'text': 'Direkt öffnen', 'href': 'apps/space-watcher-system.html'}, {'text': 'Direkt öffnen', 'href': 'apps/banking-api-explorer.html'}, {'text': 'Direkt öffnen', 'href': 'apps/media-gallery.html'}, {'text': 'Direkt öffnen', 'href': 'apps/files.html'}, {'text': 'Direkt öffnen', 'href': 'apps/stage-toolbox.html'}, {'text': 'Direkt öffnen', 'href': 'apps/digitalnotariat.html'}, {'text': 'Direkt öffnen', 'href': 'apps/guitar-html-notariat.html'}, {'text': 'Direkt öffnen', 'href': 'apps/nassis-module.html'}, {'text': 'Direkt öffnen', 'href': 'apps/build-suite.html'}, {'text': 'Direkt öffnen', 'href': 'apps/webrtc-test-harness.html'}, {'text': 'Direkt öffnen', 'href': 'apps/techniques-management.html'}, {'text': 'Direkt öffnen', 'href': 'apps/provider-management.html'}, {'text': 'Öffnen', 'href': 'apps/feature-flags.html'}, {'text': 'Öffnen', 'href': 'apps/zero-trust-center.html'}, {'text': 'Öffnen', 'href': 'apps/maintaine-ai.html'}, {'text': 'Öffnen', 'href': 'apps/telemetry-studio.html'}]
- **images:** []
- **scripts:** ['AI-API-SYSTEM-UNIVERSAL.js', 'NIE-WIEDER-AUS-SERVER-SYSTEM.js', 'real-metrics-api.js', 'build-hash-system.js', 'eternal-maintain-ai.js', 'ai-link-control-system.js', 'navigation-gap-fixer.js', 'enhanced-ui-system.js', '\\', '\\', '\\', '\\', '\\', '\\']
- **forms:** 0
- **content_length:** 52660

