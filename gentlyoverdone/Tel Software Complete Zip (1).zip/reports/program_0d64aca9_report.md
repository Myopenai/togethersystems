# Program Analysis Report - 0d64aca9

**Original File:** Gitarre Html.html
**Source URL:** https://tel1.jouwweb.nl/_downloads/a1608f86e205b5c50d7aac9fbfc757dc
**File Size:** 79180 bytes
**Content Type:** text/html; charset=UTF-8

## File Analysis

### Gitarre Html.html
- **Type:** html
- **Size:** 79180 bytes
- **Extension:** .html
- **title:** Gitarren‑Akkord‑Transposer – ohne Build
- **headings:** ['🎸 Gitarren‑Akkord‑Transposer (Single‑File)', '🎵 Häufige Akkordfolgen', 'Griffbilder', 'ASCII‑TAB Vorschau', '🎼 Musiknotation', '🎵 Producer & Kontakt', '🎧 Gentlyoverdone auf Spotify', '🎧 Gentlyoverdonelivestudio Album', '📺 Gentlyoverdone YouTube Playlist', '📺 TEL & Gentlyoverdone Live Studio', 'Neues Projekt erstellen', 'Projekte laden', 'Noten eingeben', 'Live-Noten-Anzeige', 'Multimedia-Player']
- **links:** [{'text': 'gentlyoverdone@outlook.com', 'href': 'mailto:gentlyoverdone@outlook.com'}, {'text': 'www.tel1.nl', 'href': 'https://tel1.jouwweb.nl/contact'}, {'text': 'www.gentlyoverdone.com', 'href': 'https://www.gentlyoverdone.com'}, {'text': '🎵 Magnitudo Musica Mundo unterstützen', 'href': 'https://www.gofundme.com/f/magnitudo?utm_campaign=unknown&utm_medium=referral&utm_source=widget'}]
- **images:** []
- **scripts:** ['https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js', 'https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.29/jspdf.plugin.autotable.min.js']
- **forms:** 0
- **content_length:** 78748

### metadata.json
- **Type:** json
- **Size:** 79 bytes
- **Extension:** .json
- **error:** name 'v' is not defined

