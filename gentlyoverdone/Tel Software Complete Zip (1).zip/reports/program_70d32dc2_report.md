# Program Analysis Report - 70d32dc2

**Original File:** Cv R D Tel Html Html.html
**Source URL:** https://tel1.jouwweb.nl/_downloads/295026e9d8574f1cca4757dc65a94aa8
**File Size:** 195700 bytes
**Content Type:** text/html; charset=UTF-8

## File Analysis

### Cv R D Tel Html Html.html
- **Type:** html
- **Size:** 195700 bytes
- **Extension:** .html
- **title:** Raymond Demitrio Tel | TEL & Gently Overdone
- **headings:** ['🎵 TEL & Gently Overdone', '🎵 Willkommen bei TEL & Gently Overdone', '🎨 Kreative Freiheit', '🎵 Musik & Medien', '🌍 Mehrsprachig', '🖥️ Ultimate Multimedia WYSIWYG CMS', '📁 Dateiverwaltung & Medien', '📤 Dateien hochladen', '🎯 Intelligente Größenanpassung', '🔍 Dateitypen filtern', '📊 Statistiken', '📚 Medienbibliothek', '📝 WYSIWYG Editor', '🎬 Präsentationsmodus', 'Willkommen zur Präsentation', 'Raymond Demitrio Tel', 'Producer & Creative Director', '🎨 About the Artist', '🎵 Musical Journey', '🌍 Vision & Mission', '🎯 TEL1.NL Brand', '🎵 Featured Music Collection', '📺 YouTube Channel', '💭 Philosophical Approach', '📞 Get in Touch', '📧 Email', '🌐 Website', '🎵 Music', 'TEL & Gently Overdone', 'Contact', 'Quick Links']
- **links:** [{'text': 'Home', 'href': '#home'}, {'text': 'CMS', 'href': '#cms'}, {'text': 'About', 'href': '#about'}, {'text': 'gentlyoverdone@outlook.com', 'href': 'mailto:gentlyoverdone@outlook.com'}, {'text': 'tel1.nl', 'href': 'https://tel1.jouwweb.nl/-1'}, {'text': 'Spotify Playlist', 'href': 'https://open.spotify.com/playlist/7BXr0cyoKuJSH6NUdPkrQ4'}, {'text': 'gentlyoverdone@outlook.com', 'href': 'mailto:gentlyoverdone@outlook.com'}, {'text': 'tel1.nl', 'href': 'https://tel1.jouwweb.nl/-1'}, {'text': 'Spotify Discography', 'href': 'https://open.spotify.com/artist/3skMNuv9SjTqTQcDbCDk2T/discography'}, {'text': 'tel1.nl', 'href': 'https://tel1.jouwweb.nl/-1'}, {'text': 'Home', 'href': '#'}, {'text': 'CMS Editor', 'href': '#'}, {'text': 'Spotify', 'href': 'https://open.spotify.com/playlist/7BXr0cyoKuJSH6NUdPkrQ4'}, {'text': '❤️\n                        Magnitudo Musica Mundo', 'href': 'https://www.gofundme.com/f/magnitudo?utm_campaign=unknown&utm_medium=referral&utm_source=widget'}]
- **images:** []
- **scripts:** ['https://unpkg.com/tinymce@6.8.3/tinymce.min.js', 'https://cdn.jsdelivr.net/npm/jszip@3.10.1/dist/jszip.min.js']
- **forms:** 0
- **content_length:** 194553

### metadata.json
- **Type:** json
- **Size:** 88 bytes
- **Extension:** .json
- **error:** name 'v' is not defined

