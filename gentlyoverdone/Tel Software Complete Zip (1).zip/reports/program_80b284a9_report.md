# Program Analysis Report - 80b284a9

**Original File:** Budget Book 2025 Html.html
**Source URL:** https://tel1.jouwweb.nl/_downloads/d166bedcd994ba935232f10ea77befdf
**File Size:** 207187 bytes
**Content Type:** text/html; charset=UTF-8

## File Analysis

### Budget Book 2025 Html.html
- **Type:** html
- **Size:** 207187 bytes
- **Extension:** .html
- **title:** 💰 TEL Haushaltsbuch 2025 - Professional Edition
- **headings:** ['💰 TEL Haushaltsbuch 2025', '📊 Finanz-Dashboard', '⚡ Schnellaktion', '🏆 Achievements & Gamification', '💳 Transaktionen', '🎯 Budget-Planung', '📈 Finanz-Analysen', '📊 Ausgaben nach Kategorie', '📈 Cashflow-Entwicklung', '🏦 Konten-Verwaltung', '₿ Krypto-Portfolio', '🔗 Wallet-Verbindung', '💎 Deine Krypto-Assets', '📈 Portfolio-Entwicklung', '🤖 AI-Finanzassistent', '💬 Chat mit deinem persönlichen Finanzberater', '📊 AI-Erkenntnisse', '🏦 Open Banking & API-Integration', '🔌 Bank-API Konfiguration (PSD2/Open Banking)', '🔄 Auto-Import Einstellungen', '📊 Verbundene Konten', '🧾 Belege & OCR-Erkennung', '📸 Beleg hochladen & scannen', 'Beleg hochladen oder hierhin ziehen', '🔄 OCR-Verarbeitung läuft...', '✅ Erkannte Daten:', '📁 Gespeicherte Belege', '🤖 AI-Budget-Optimierung', '⚙️ Einstellungen', '🔐 Sicherheit & Datenschutz', '🤖 AI-API Konfiguration', '₿ Krypto-API Konfiguration', '☁️ Cloud-Synchronisation (WebDAV)', '🎨 Personalisierung', '💾 Daten-Verwaltung', 'ℹ️ System-Info', '💳 Neue Transaktion', '🎯 Neues Budget erstellen', '🏦 Neues Konto hinzufügen', '₿ Krypto-Asset hinzufügen']
- **links:** []
- **images:** []
- **scripts:** ['https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js', 'https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js', 'https://cdn.sheetjs.com/xlsx-0.20.1/package/dist/xlsx.full.min.js', 'https://cdn.jsdelivr.net/npm/tesseract.js@5.0.0/dist/tesseract.min.js', 'https://cdnjs.cloudflare.com/ajax/libs/crypto-js/4.2.0/crypto-js.min.js']
- **forms:** 5
- **content_length:** 205813

### metadata.json
- **Type:** json
- **Size:** 89 bytes
- **Extension:** .json
- **error:** name 'v' is not defined

