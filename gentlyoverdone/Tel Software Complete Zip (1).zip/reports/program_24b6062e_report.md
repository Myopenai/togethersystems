# Program Analysis Report - 24b6062e

**Original File:** Anderen Pdf.pdf
**Source URL:** https://tel1.jouwweb.nl/_downloads/058d13f82f067b0a5b4755b55df104f4
**File Size:** 31549 bytes
**Content Type:** application/pdf

## File Analysis

### Anderen Pdf.pdf
- **Type:** unknown
- **Size:** 31549 bytes
- **Extension:** .pdf

### extracted_text.txt
- **Type:** text
- **Size:** 958 bytes
- **Extension:** .txt
- **content_length:** 928
- **lines:** 22
- **words:** 167
- **preview:** Lieve lezer,
We leven in schaduwen, maar stralen zo fel.
We bouwen werelden van dromen, eindeloos en snel.
Hun regels, hun hokjes – wij passen daar niet in.
Onze vleugels van licht dragen ons verder, een nieuw begin.
Wij zijn de anderen, wij horen niet bij hen.
We passen niet in hun laatjes, we breken de stem.
We reizen door het universum, zo ver en zo vrij.
Wij zijn de anderen  – zij bereiken ons nooit, hoe hard ze ook proberen.
Zij vullen hun laatjes, gedreven door angst,
maar wij vinden de st...

