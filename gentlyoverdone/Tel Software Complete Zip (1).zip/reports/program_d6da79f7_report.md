# Program Analysis Report - d6da79f7

**Original File:** Cms System Rdtel Zip.zip
**Source URL:** https://tel1.jouwweb.nl/_downloads/b3940875a1d0e51affda146f718b8003
**File Size:** 36679 bytes
**Content Type:** application/zip

## File Analysis

### index.htm
- **Type:** html
- **Size:** 246508 bytes
- **Extension:** .htm
- **title:** Advanced Builder - Vollständig Funktional
- **headings:** ['🚀 Schnell-Komponenten', '📝 Grundlegende Komponenten\n                    ℹ️ Info', '🔄 MODX Extras & Add-ons', '⚡ Erweiterte Widgets', '🚀 Enterprise Features', '📋 MODX Templates', '⚙️ MODX System Settings', '🌐 Website-Einstellungen', '🔒 Sicherheit', '📧 E-Mail-Einstellungen', '🔍 SEO & Analytics', '🌐 Erweiterte Einstellungen', '🖼️ Bild hochladen', '✏️ Komponente bearbeiten']
- **links:** [{'text': 'ℹ️ Info', 'href': 'javascript:void(0)'}]
- **images:** []
- **scripts:** []
- **forms:** 0
- **content_length:** 245052

