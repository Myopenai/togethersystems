# Program Analysis Report - ee655320

**Original File:** Gitarre Html Visionview Must Be Updated Html.html
**Source URL:** https://tel1.jouwweb.nl/_downloads/a04ab7e5ad2830e520ce4a4456d4afa5
**File Size:** 720241 bytes
**Content Type:** text/html; charset=UTF-8

## File Analysis

### Gitarre Html Visionview Must Be Updated Html.html
- **Type:** html
- **Size:** 720241 bytes
- **Extension:** .html
- **title:** Vollständiges Musikbildungsprogramm – 50+ Tools für Gitarre, Klavier, Theorie, Gehörbildung, Rhythmus, Komposition & Produktion
- **headings:** ['🎵 Vollständiges Musikbildungsprogramm – 50+ Tools', '🎸 Live-Akkord-Sharing aktiv', '🎵 Häufige Akkordfolgen - Alle Genres', '🔄 Song-Wiederholung', 'Griffbilder', 'ASCII‑TAB Vorschau', '🎼 Musiknotation', '🎵 Producer & Kontakt', '🎹 Virtuelles Klavier', '🎼 Klavier-Notation', '🎹 Klavier-Übungen', '🎵 Tonleitern & Modi', '🎼 Akkord-Analyse', '🎵 Fortschreitungen', '🎼 Funktionstheorie', '🎵 Intervall-Training', '🎼 Akkord-Erkennung', '🎸 Instrument-Auswahl', '🎵 Melodie-Erkennung', '🎼 Rhythmus-Erkennung', '🥁 Drum Machine', '🎼 Rhythmus-Notation', '🥁 Rhythmus-Übungen', '🎵 Melodie-Generator', '🎼 Bass-Linien', '🎵 Harmonische Progressionen', '🎼 Song-Struktur', '🎛️ Virtueller Mixer', '🎵 TEL & Gentlyoverdone', 'TEL & Gentlyoverdone', '🎧 Gentlyoverdone op Spotify', '🎧 Gentlyoverdonelivestudio op Spotify', '🎧 TEL & Gentlyoverdone Playlist', '📺 Gentlyoverdone op YouTube', '📺 Gentlyoverdonelivestudio op YouTube', '📺 TEL & Gentlyoverdone Video Playlist', 'ℹ️ Over het Project', '🔗 Volg ons', '🎵 Effekt-Prozessor', '🎼 Mastering-Tools', '🎵 Export & Rendering', '🎵 Audio-Import & Bearbeitung', '🎼 Waveform-Editor', '🎛️ Effekt-Kette & Dolby', '⏯️ Transport & Steuerung', '💾 Export & Mixdown', '🎯 Live-Performance & Optimierung', '🎼 Waveframe Audio-Editor', '🎛️ Multi-Track Recording', '🎵 Song-Projekt-Manager', '🎵 Live Setlist Manager', '🎚️ Stage Monitor & Mix', '⏱️ Tempo & Timing', '🎼 Chord Charts & Lyrics', '🎯 Performance Tools', '🎧 Gentlyoverdone auf Spotify', '🎧 Gentlyoverdonelivestudio Album', '📺 Gentlyoverdone YouTube Playlist', '📺 TEL & Gentlyoverdone Live Studio', 'TEL & Gentlyoverdone', '🎧 Gentlyoverdone op Spotify', '🎧 Gentlyoverdonelivestudio op Spotify', '🎧 TEL & Gentlyoverdone Playlist', '📺 Gentlyoverdone op YouTube', '📺 Gentlyoverdonelivestudio op YouTube', '📺 TEL & Gentlyoverdone Video Playlist', 'ℹ️ Over het Project', '🔗 Volg ons', 'Neues Projekt erstellen', 'Projekte laden', 'Noten eingeben', 'Live-Noten-Anzeige', 'Multimedia-Player']
- **links:** [{'text': 'gentlyoverdone@outlook.com', 'href': 'mailto:gentlyoverdone@outlook.com'}, {'text': 'www.tel1.nl', 'href': 'https://tel1.jouwweb.nl/contact'}, {'text': 'www.gentlyoverdone.com', 'href': 'https://www.gentlyoverdone.com'}, {'text': '🎵 Magnitudo Musica Mundo unterstützen', 'href': 'https://www.gofundme.com/f/magnitudo?utm_campaign=unknown&utm_medium=referral&utm_source=widget'}, {'text': 'tel1.nl', 'href': 'https://www.tel1.nl'}, {'text': 'gentlyoverdone.com', 'href': 'https://www.gentlyoverdone.com'}, {'text': 'Instagram', 'href': 'https://www.instagram.com/gentlyoverdone'}, {'text': 'Facebook', 'href': 'https://www.facebook.com/gentlyoverdone'}, {'text': 'Twitter', 'href': 'https://twitter.com/gentlyoverdone'}, {'text': 'tel1.nl', 'href': 'https://www.tel1.nl'}, {'text': 'gentlyoverdone.com', 'href': 'https://www.gentlyoverdone.com'}, {'text': 'Instagram', 'href': 'https://www.instagram.com/gentlyoverdone'}, {'text': 'Facebook', 'href': 'https://www.facebook.com/gentlyoverdone'}, {'text': 'Twitter', 'href': 'https://twitter.com/gentlyoverdone'}]
- **images:** ['https://tse4.mm.bing.net/th/id/OIP.DSkAHippfPm7Y3kbZ57D4QHaDt?pid=Api', 'https://tse4.mm.bing.net/th/id/OIP.DSkAHippfPm7Y3kbZ57D4QHaDt?pid=Api']
- **scripts:** ['https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js', 'https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.29/jspdf.plugin.autotable.min.js']
- **forms:** 0
- **content_length:** 714875

### metadata.json
- **Type:** json
- **Size:** 112 bytes
- **Extension:** .json
- **error:** name 'v' is not defined

