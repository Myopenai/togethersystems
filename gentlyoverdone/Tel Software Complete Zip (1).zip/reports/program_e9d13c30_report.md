# Program Analysis Report - e9d13c30

**Original File:** Notar Production Instructions 2 Zip.zip
**Source URL:** https://tel1.jouwweb.nl/_downloads/de1761d352ff9289ecec2cc7e4a1759d
**File Size:** 37948 bytes
**Content Type:** application/zip

## File Analysis

### Notar production instructions.zip
- **Type:** zip
- **Size:** 38980 bytes
- **Extension:** .zip
- **file_count:** 15
- **files:** ['FEHLERANALYSE_ZUSAMMENFASSUNG.md', 'GoBD-Compliance.en.md', 'GoBD-Compliance.nl.md', 'KASSENBUCH_TRANSLATIONS.md', 'TEL1_LINK_IMPLEMENTATION.md', 'ARCHIV_CHECKBOX_FEATURES.md', 'ARCHIV_CHECKBOX_FEATURES-EN.md', 'ARCHIV_CHECKBOX_FEATURES-NL.md', 'ARCHIV_EXPORT_ANLEITUNG.md', 'BANK_API_GOBD_DOKUMENTATION.md']
- **total_size:** 99210

### installation-npm-pnpm.txt
- **Type:** text
- **Size:** 269 bytes
- **Extension:** .txt
- **content_length:** 265
- **lines:** 1
- **words:** 36
- **preview:** echo "🔧 Vollständiges Setup..." && curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.0/install.sh | bash && source ~/.bashrc && nvm install 18 && nvm use 18 && npm install -g pnpm && cd domains/digitalnotar.in/public_html && pnpm install && pnpm run build

