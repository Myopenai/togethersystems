# Program Analysis Report - 59a4dda7

**Original File:** index.html
**Source URL:** https://viewunitysystemt.github.io/TELCOTELEKOM/index.html
**File Size:** 419414 bytes
**Content Type:** text/html; charset=utf-8

## File Analysis

### index.html
- **Type:** html
- **Size:** 1870 bytes
- **Extension:** .html
- **title:** Borkum grüsst den Rest der Welt !
- **headings:** ['Achtung!']
- **links:** [{'text': 'Netscape', 'href': 'http://www.netscape.com'}, {'text': 'MS Internet Explorer', 'href': 'http://www.microsoft.de'}]
- **images:** []
- **scripts:** []
- **forms:** 0
- **content_length:** 1866

### metadata.json
- **Type:** json
- **Size:** 71 bytes
- **Extension:** .json
- **error:** name 'v' is not defined

