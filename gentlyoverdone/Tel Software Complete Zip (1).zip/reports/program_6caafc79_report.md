# Program Analysis Report - 6caafc79

**Original File:** Tel 1 Pitchdeck 2025 De En Nl Zip.zip
**Source URL:** https://tel1.jouwweb.nl/_downloads/8946b9fdb443f5ec9810fbf459d75f20
**File Size:** 95732 bytes
**Content Type:** application/zip

## File Analysis

### Tel_1_Pitchdeck_2025_DE.pptx
- **Type:** unknown
- **Size:** 43363 bytes
- **Extension:** .pptx

### Tel_1_Pitchdeck_2025_EN.pptx
- **Type:** unknown
- **Size:** 43205 bytes
- **Extension:** .pptx

### Tel_1_Pitchdeck_2025_NL.pptx
- **Type:** unknown
- **Size:** 43269 bytes
- **Extension:** .pptx

