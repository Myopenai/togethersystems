# Program Analysis Report - ac831846

**Original File:** Financieel Plan Pdf.pdf
**Source URL:** https://tel1.jouwweb.nl/_downloads/671fa5e537993cce0ff267c569a9342e
**File Size:** 28705 bytes
**Content Type:** application/pdf

## File Analysis

### extracted_text.txt
- **Type:** text
- **Size:** 3124 bytes
- **Extension:** .txt
- **content_length:** 2995
- **lines:** 59
- **words:** 360
- **preview:** Financieel plan tel1.nl voor een onderneming met een startkapitaal van €250.000, gericht op het 
genereren van een maandelijkse omzet tussen €5.000 en €10.000 via tel1.nl:  
---
### **1. Investeringsbegroting**  
**Totaal beschikbare kapitaal: €250.000**  
#### **A. Initiële kosten**  
1. **Websiteontwikkeling en platformintegratie**  
   - Professionele website en e-commerce integratie: €25.000  
   - Onderhoud en hosting voor 3 jaar: €10.000  
2. **Marketing en branding**  
   - Branding (logo...

### Financieel Plan Pdf.pdf
- **Type:** unknown
- **Size:** 28705 bytes
- **Extension:** .pdf

