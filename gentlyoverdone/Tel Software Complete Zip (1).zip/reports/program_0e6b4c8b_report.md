# Program Analysis Report - 0e6b4c8b

**Original File:** Testversion 0001 Gitarre Html Zip.zip
**Source URL:** https://tel1.jouwweb.nl/_downloads/f615236d9b97c44bc0f0a9120a167ecc
**File Size:** 88863 bytes
**Content Type:** application/zip

## File Analysis

### Gitarre Html.html
- **Type:** html
- **Size:** 425465 bytes
- **Extension:** .html
- **title:** Gitarren‑Akkord‑Transposer – ohne Build
- **headings:** ['🎸 Gitarren‑Akkord‑Transposer (Single‑File)', '🎯 Studio-System Übersicht', '🧪 Vollständige Test-Suite', '🎵 Häufige Akkordfolgen', '🎼 Erweiterte Akkordfolgen für Produktion', '💾 Gespeicherte Lieder', '🎵 Automatische Backing-Tracks', 'Griffbilder', 'ASCII‑TAB Vorschau', '🎼 Musiknotation', '🎵 Producer & Kontakt', '🌐 Gentlyoverdone Producer Network', '🎵 Hauptwebsite', '🎸 TEL1 Studio', '🎼 Magnitudo Musica', '🎧 Gentlyoverdone auf Spotify', '🎧 Gentlyoverdonelivestudio Album', '📺 Gentlyoverdone YouTube Playlist', '📺 TEL & Gentlyoverdone Live Studio', '📰 Producer-News & Updates', '🎵 Neue Releases', '🎸 Studio-Services', '🎼 Community', '🎵 Neues Musik-Projekt erstellen', '📂 Projekte laden & verwalten', '🎼 Projekt-Musik-Integration', '🎸 Akkord-Progression', '🎵 Noten & Melodie', '🎛️ Projekt-Sound-Einstellungen', '🎸 Gitarre', '🎸 Bass', '🥁 Drums', '🎵 Noten eingeben & parsen', '🎼 Live-Noten-Anzeige & Animation', '🎵 Multimedia-Integration', '🎼 Noten-Transformation', '🎸 Intelligente Griffbild-Eingabe', '🎼 Akkord-Eingabe über Griffbild', '🎵 Single-Noten-Eingabe']
- **links:** [{'text': 'gentlyoverdone@outlook.com', 'href': 'mailto:gentlyoverdone@outlook.com'}, {'text': 'www.tel1.nl', 'href': 'https://tel1.jouwweb.nl/contact'}, {'text': 'www.gentlyoverdone.com', 'href': 'https://www.gentlyoverdone.com'}, {'text': '🎵 Magnitudo Musica Mundo unterstützen', 'href': 'https://www.gofundme.com/f/magnitudo?utm_campaign=unknown&utm_medium=referral&utm_source=widget'}, {'text': '🌐 Besuchen', 'href': 'https://www.gentlyoverdone.com'}, {'text': '📞 Kontakt', 'href': 'https://tel1.jouwweb.nl/contact'}, {'text': '💰 Unterstützen', 'href': 'https://www.gofundme.com/f/magnitudo?utm_campaign=unknown&utm_medium=referral&utm_source=widget'}, {'text': '🎵 Auf Spotify folgen', 'href': 'https://open.spotify.com/artist/4JoHEGXx9uwPmdT02ZSVwH'}, {'text': '💿 Album anhören', 'href': 'https://open.spotify.com/album/5Sk4bMBNLz8VfTeIliJIgw'}, {'text': '▶️ Playlist abonnieren', 'href': 'https://www.youtube.com/playlist?list=OLAK5uy_n9sfv4rSbaRrk-_NA1RMznMMC3gTbk_VM'}, {'text': '🎬 Live-Sessions', 'href': 'https://www.youtube.com/playlist?list=OLAK5uy_kEtsbqqFe8StPkTQp-7CiNJy2tzNMHXzk'}, {'text': 'Mehr erfahren →', 'href': 'https://www.gentlyoverdone.com'}, {'text': 'Kontakt aufnehmen →', 'href': 'https://tel1.jouwweb.nl/contact'}, {'text': 'Beitreten →', 'href': 'https://www.gofundme.com/f/magnitudo'}]
- **images:** []
- **scripts:** ['https://cdn.jsdelivr.net/npm/tone@14.8.49/build/Tone.js', 'https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js', 'https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.29/jspdf.plugin.autotable.min.js', 'https://cdn.jsdelivr.net/npm/soundfont-player@0.15.7/dist/soundfont-player.min.js', 'https://unpkg.com/midi-writer-js@3.1.1/build/index.min.js', 'https://cdn.jsdelivr.net/npm/lamejs@1.2.0/lame.min.js']
- **forms:** 0
- **content_length:** 422877

