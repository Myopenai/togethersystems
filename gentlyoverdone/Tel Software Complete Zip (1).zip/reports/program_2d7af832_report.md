# Program Analysis Report - 2d7af832

**Original File:** schermafbeelding-2025-08-25-064651-high.png
**Source URL:** https://primary.jwwb.nl/public/h/o/b/temp-nyratlbjkkriqxftlyfy/schermafbeelding-2025-08-25-064651-high.png
**File Size:** 101115 bytes
**Content Type:** image/png

## File Analysis

### metadata.json
- **Type:** json
- **Size:** 104 bytes
- **Extension:** .json
- **error:** name 'v' is not defined

### schermafbeelding-2025-08-25-064651-high.png
- **Type:** unknown
- **Size:** 101115 bytes
- **Extension:** .png

