# Program Analysis Report - ddd12b3a

**Original File:** Cullinary Mmm Magnitudo Musica Mundo Html.html
**Source URL:** https://tel1.jouwweb.nl/_downloads/9ac78d7c7b283e5c53bef23329a20281
**File Size:** 151577 bytes
**Content Type:** text/html; charset=UTF-8

## File Analysis

### Cullinary Mmm Magnitudo Musica Mundo Html.html
- **Type:** html
- **Size:** 151577 bytes
- **Extension:** .html
- **title:** MMM - MAGNITUDO MUSICA MUNDO – One File Universal Platform
- **headings:** ['MMM - MAGNITUDO MUSICA MUNDO', 'Rezept', 'Zutaten', 'Zubereitung', 'Aktionen']
- **links:** [{'text': 'TEL1.NL', 'href': 'https://tel1.jouwweb.nl/-2'}, {'text': 'gentlyoverdone@outlook.com', 'href': 'mailto:gentlyoverdone@outlook.com'}, {'text': 'www.tel1.nl', 'href': 'https://tel1.jouwweb.nl/-2'}, {'text': 'Magnitudo', 'href': 'https://www.gofundme.com/f/magnitudo?utm_campaign=unknown&utm_medium=referral&utm_source=widget'}]
- **images:** []
- **scripts:** []
- **forms:** 0
- **content_length:** 149858

### metadata.json
- **Type:** json
- **Size:** 109 bytes
- **Extension:** .json
- **error:** name 'v' is not defined

