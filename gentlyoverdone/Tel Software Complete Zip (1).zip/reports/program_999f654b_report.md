# Program Analysis Report - 999f654b

**Original File:** Scienceformulars Zip.zip
**Source URL:** https://tel1.jouwweb.nl/_downloads/bf8494d4d63d78c3e4aad783e1a0b6f7
**File Size:** 27385 bytes
**Content Type:** application/zip

## File Analysis

### 🔬-FORSCHUNG-KOMPLETT.html
- **Type:** html
- **Size:** 23603 bytes
- **Extension:** .html
- **title:** 🔬 FORSCHUNGS-SYSTEM - Einheiten, Stoffe & Interaktive Chemie
- **headings:** ['⚠️ WICHTIGE SICHERHEITSHINWEISE', '🔬 FORSCHUNGS-SYSTEM KOMPLETT', '⚡ Universal Converter', '✅ Ergebnis', '🧪 Stoffdatenbank', '⚛️ Periodensystem', '🔬 Interaktiver Element-Kombinator', 'Elemente auswählen & kombinieren', 'Aktuelle Kombination', '⚠️ Sicherheitsregeln & Compliance', '🚫 VERBOTEN - Keine praktische Umsetzung ohne Lizenz!', '✅ Erlaubt - Theoretische Forschung', '📚 Ressourcen für sichere Forschung', '🔬 Für reale Umsetzung kontaktieren:']
- **links:** []
- **images:** []
- **scripts:** []
- **forms:** 0
- **content_length:** 23365

### 🔬-INTERACTIVE-COMPLETE.html
- **Type:** html
- **Size:** 31095 bytes
- **Extension:** .html
- **title:** 🔬 Interactive Lab System - Mit Erklärungs-Popups
- **headings:** ['🔬 Interactive Lab System', 'ℹ️ Interaktive Hilfe', '🔬 Interaktiver Element-Kombinator', '⚛️ Valenzprüfung', '🔋 Elektronegativität (EN)', '🔗 Bindungsanalyse', 'Element auswählen', 'Aktuelle Kombination', '💡 Hinweise zur Interpretation', '📐 Heuristische Schätzungen', '🌐 PubChem', '🇩🇪 GESTIS-Stoffdatenbank', '🔍 ChemSpider', '⚗️ Etablierte Laborverfahren', '📚 Wissenschaftliche Ressourcen & Institutionen', '🌐 Internationale Datenbanken', '🌐 PubChem - NIH Database', '🇩🇪 GESTIS-Stoffdatenbank', '🔍 ChemSpider - RSC Database', '🇺🇸 NIST Chemistry WebBook', '🇪🇺 EU-Behörden & Compliance', '🇪🇺 ECHA - European Chemicals Agency', '🇩🇪 BfR - Bundesinstitut für Risikobewertung', '🇩🇪 BAuA - Bundesanstalt für Arbeitsschutz', '🎓 Universitäten & Forschungseinrichtungen', '🔬 MPI für Chemie', '🏭 Fraunhofer-Gesellschaft', '🏭 Chemie-Industrie', '📋 ELN-Export (Electronic Lab Notebook)', 'ℹ️ Was ist ein ELN?', '📓 Electronic Lab Notebook (ELN)', 'Protokoll-Informationen', '⚛️ Periodensystem (Interaktiv)']
- **links:** [{'text': 'pubchem.ncbi.nlm.nih.gov', 'href': 'https://pubchem.ncbi.nlm.nih.gov'}, {'text': 'gestis.dguv.de', 'href': 'https://gestis.dguv.de'}, {'text': 'chemspider.com', 'href': 'https://www.chemspider.com'}, {'text': 'pubchem.ncbi.nlm.nih.gov', 'href': 'https://pubchem.ncbi.nlm.nih.gov'}, {'text': 'gestis.dguv.de', 'href': 'https://gestis.dguv.de'}, {'text': 'chemspider.com', 'href': 'https://www.chemspider.com'}, {'text': 'webbook.nist.gov', 'href': 'https://webbook.nist.gov'}, {'text': 'echa.europa.eu', 'href': 'https://echa.europa.eu'}, {'text': 'bfr.bund.de', 'href': 'https://www.bfr.bund.de'}, {'text': 'baua.de', 'href': 'https://www.baua.de'}, {'text': 'mpic.de', 'href': 'https://www.mpic.de'}, {'text': 'fraunhofer.de', 'href': 'https://www.fraunhofer.de'}]
- **images:** []
- **scripts:** []
- **forms:** 0
- **content_length:** 30695

### 🔬-PROFESSIONAL-LAB-SYSTEM.html
- **Type:** html
- **Size:** 33118 bytes
- **Extension:** .html
- **title:** 🔬 Professional Lab System - Vollständige Forschungsumgebung
- **headings:** ['🔬 Professional Lab System', '🔬 Element-Kombinator (Erweiterte Valenzprüfung)', 'Element auswählen', 'Aktuelle Kombination', '⚗️ Protokoll-Generator (ELN-Template)', 'Protokoll-Informationen', '⚠️ Sicherheit & Compliance', '🚫 VERBOTEN ohne Genehmigung:', '✅ ERLAUBT in lizensierten Einrichtungen:', '📚 Gesetzliche Grundlagen (Deutschland/EU)', '🔬 Erforderliche Qualifikationen', '📋 ELN-Export (Electronic Lab Notebook)', 'ELN-Entry Konfiguration', '⚛️ Periodensystem (mit Bindungs-Info)', '📊 Audit-Trail & Compliance-Log']
- **links:** []
- **images:** []
- **scripts:** []
- **forms:** 0
- **content_length:** 32832

