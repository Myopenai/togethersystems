# Program Analysis Report - 3d928372

**Original File:** download_3d928372.bin
**Source URL:** https://tel1.jouwweb.nl/servicesoftware
**File Size:** 266130 bytes
**Content Type:** text/html; charset=UTF-8

## File Analysis

### download_3d928372.bin
- **Type:** unknown
- **Size:** 266130 bytes
- **Extension:** .bin

### metadata.json
- **Type:** json
- **Size:** 84 bytes
- **Extension:** .json
- **error:** name 'v' is not defined

