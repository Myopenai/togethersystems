# Program Analysis Report - 829cccf3

**Original File:** schermafbeelding-2025-08-22-154536-high.png
**Source URL:** https://primary.jwwb.nl/public/h/o/b/temp-nyratlbjkkriqxftlyfy/schermafbeelding-2025-08-22-154536-high.png
**File Size:** 652478 bytes
**Content Type:** image/png

## File Analysis

### metadata.json
- **Type:** json
- **Size:** 104 bytes
- **Extension:** .json
- **error:** name 'v' is not defined

### schermafbeelding-2025-08-22-154536-high.png
- **Type:** unknown
- **Size:** 652478 bytes
- **Extension:** .png

