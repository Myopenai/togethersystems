# Cursor SFTP One‑Prompt Pack
Ziel: **Ein Prompt** in Cursor („deploy jetzt“) triggert ein **vollautomatisches SFTP‑Deploy**.
## Setup
1) `cd mcp-sftp && npm i`
2) `.env.example` → `.env` mit SFTP‑Zugang füllen
3) `.cursor/mcp.json` ins Projekt kopieren (falls vorhanden: mergen)

## Nutzung
Im Cursor‑Chat: **deploy jetzt** – Cursor ruft Tool `deploy_default` (MCP `sftp`) auf.
Weitere Prompts: „list /var/www/html“, „sync ./dist → /var/www/html“.

## Sicherheit
SSH‑Key bevorzugen; `.env` nicht committen.
