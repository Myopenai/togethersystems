# Branding – Legal & Verification (Demo)

Dieses Verzeichnis enthält Demo-Branding-Assets für die Integration eines Legal-/Verifikationsbereichs in **T,.&T,,.&T,,,.TOGETHERSYSTEMS. INTERNATIONAL TTT T,.&T,,.T,,,.(C) (+31) - ( 613 803 782.) https://orcid.org/0009-0003-1328-2430**.

- `de_rechtspraak.png` + Varianten: transparente PNG-Dateien in mehreren Größen.
- `de_rechtspraak.svg`: SVG-Hülle, die das PNG einbettet (Platzhalter, keine amtliche Reproduktion).
- Diese Dateien dienen ausschließlich zu Demonstrationszwecken innerhalb der Applikation.

Hinweis: Die Nutzung offizieller Logos kann marken- und urheberrechtlichen Restriktionen unterliegen. 
Für produktiven Einsatz müssen die Rechte vorab geprüft und ggf. Genehmigungen eingeholt werden.
