# Start Python HTTP Server für Playwright Tests
Write-Host "Starting Python HTTP Server on port 9323..." -ForegroundColor Green
Write-Host "Press Ctrl+C to stop the server" -ForegroundColor Yellow
python -m http.server 9323

