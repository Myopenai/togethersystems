# Zero-Input-Flow Architektur

## 🎯 Vision

**Der User soll das System einfach "fahren" wie ein autonomes Fahrzeug.**
- Nur kommunizieren, keine Konfiguration
- Keine Formular-Hölle
- Automatische Verbindungen, automatische Räume, automatische Slots

---

## 📋 Phase 1: Presence-Auto-Init (SOFORT umsetzbar)

### Ziel
Beim Laden von `manifest-portal.html`:
- ✅ Automatisch `/api/presence/verify` aufrufen (ohne User-Eingabe)
- ✅ `thinker_id` in `localStorage` speichern
- ✅ Auf jeder Seite: Alle X Sekunden `/api/presence/heartbeat` → User ist "online"

### Implementierung
Siehe `manifest-portal.html` - Funktion: `autoConnectFromToken()`

**Status:** ✅ Bereits teilweise implementiert, muss nur automatisch beim Seitenladen ausgeführt werden

---

## 📋 Phase 2: One-Click-Matching (NÄCHSTER SCHRITT)

### Ziel
Statt manuell `pair_code` eintippen:
- ✅ `pair_code` kann für einen Kontakt/Link automatisch generiert werden
- ✅ In der URL stehen: `https://.../manifest-portal.html?room=ABCD`
- ✅ Der zweite Nutzer klickt auf den Link → Frontend liest `room`-Param
- ✅ Ruft `/api/presence/verify` und `/match` automatisch

**Ergebnis:** Der User macht nur einen Link-Klick, keine Eingabe.

### Implementierung
Siehe Code-Snippets unten

---

## 📋 Phase 3: Konversations-Start-Templates

### Ziel
In `manifest-portal.html`:
- ✅ Statt langem Formular: Buttons wie "Call", "Chat", "Group Session"
- ✅ Dahinter werden intern:
  - Voucher/Slots (falls nötig) erzeugt
  - Presence & WebSocket-Room angelegt
  - Telbank-Flows vorbereitet

### Implementierung
Siehe Code-Snippets unten

---

## 📋 Phase 4: Voucher & Slots automatisch

### Ziel
Der User klickt: "Call mit X planen"
- ✅ Frontend fragt `/api/slots/available` für X
- ✅ Wählt automatisch den ersten passenden Slot
- ✅ Bucht den Slot via `/api/voucher/book`
- ✅ User sieht nur: "Termin am Dienstag, 14:00 steht – Join-Button"

**→ Keine Eingabe, nur Bestätigung**

---

## 📋 Phase 5: Kontaktliste + Presence kombinieren

### Ziel
Eine simple "Contact Card"-Liste anzeigen:
- ✅ Für jeden Kontakt:
  - Status (online/offline) über Presence-API
  - "Join Conversation"-Button:
    - Triggert intern `pair_code`-Generierung + `/match` + WebSocket-Join

**Der User klickt nur noch auf Personen, nicht auf technische Dinge.**

---

## 🔧 Implementierungs-Details

### Was im Code jetzt schon als Features drinsteckt

Aus dem Code kann man folgende (teilweise "versteckte") Features erkennen:

#### ✅ Presence / Matching
- `/api/presence/verify`, `/heartbeat`, `/match`, `/debug`
- Token + HMAC-Option, `thinker_id`, `pair_code`, `room_id`
- Matching-Logik, um zwei Leute mit gleichem `pair_code` in denselben Raum zu stecken

#### ✅ WebSocket-Livechat
- `functions/ws.js` → `/ws`
- Rooms, Broadcast, basic Signaling – vorbereitet für Live-Communication

#### ✅ Telbank
- Frontend: `TELBANK/index.html`, `TELBANK/telbank-app.js`
- Backend: `/api/telbank/transfers` (D1-Tabelle `transfers`)
- Event-Sourcing-Light über Tabelle `events`

#### ✅ Voucher & Slots
- Backend: `/api/voucher/issue`, `/book`, `/cancel`, `/bookings`
- Noch eine API `/api/slots/available`
- Kann man nutzen für Zeit-Slots, Sessions, Gespräche, etc.

#### ✅ Mortgage-Flow
- `/api/mortgage/application`, `/offer`, `/offer-list`
- D1-Tabellen `mortgage_applications`, `mortgage_offers`, `mortgage_contracts`

#### ✅ Contracts & Upload
- `/api/contracts/upload`, `/list`
- Integration mit D1, optional R2 (derzeit nicht aktiv)

#### ✅ Telemetry & Autofix
- `/api/telemetry` mit `TS_API_KEY` und Rate Limits
- `/api/autofix/errors`, `/status`, `/notify`
- `autofix-client.js` integrierbar in jede Seite:
  - Fehler werden gesammelt
  - Backendseitig analysiert
  - Benutzer bekommt hübsche Notifs ("Fix vorgeschlagen")

#### ✅ Admin-Monitoring, Honeycomb, Ambient Media
- `admin-monitoring.html`, `business-admin.html`, `honeycomb.html`, `ambient-media.js`
- Visualisierung von Events, Räumen, Traffic, etc.

**Das ist keine Dummy-Doku – das ist echte, greifbare Funktionalität im Code.**

---

## 🚀 Roadmap (3–5 Phasen)

### Phase 1: Presence-Auto-Init ✅ (SOFORT)
- [x] Automatische `thinker_id`-Generierung beim Seitenladen
- [x] Automatischer Heartbeat alle X Sekunden
- [ ] Auto-Verifizierung ohne Token (optional)

### Phase 2: One-Click-Match 🔄 (NÄCHSTER SCHRITT)
- [ ] URL-Parameter `?room=ABCD` lesen
- [ ] Automatisch `pair_code` aus URL generieren
- [ ] Automatisch `/api/presence/match` aufrufen
- [ ] Automatisch WebSocket-Room joinen

### Phase 3: Konversations-Templates 📅
- [ ] "Call", "Chat", "Group Session" Buttons
- [ ] Automatische Voucher/Slot-Erzeugung
- [ ] Automatischer WebSocket-Room-Aufbau

### Phase 4: Auto-Slots 📅
- [ ] Automatische Slot-Auswahl
- [ ] Automatische Buchung
- [ ] Bestätigungs-UI

### Phase 5: Kontaktliste 📅
- [ ] Presence-Status pro Kontakt
- [ ] "Join Conversation" Button
- [ ] Automatischer Match + WebSocket-Join

---

## 📝 Nächste Schritte

1. ✅ Code-Snippets für Presence-Auto-Init + One-Click-Match implementieren
2. ✅ In `manifest-portal.html` integrieren
3. ✅ Testen
4. ⏭ Phase 3-5 nach und nach umsetzen


---

## 🏢 Unternehmens-Branding & OCR

**TogetherSystems** | **T,.&T,,.&T,,,.** | **TTT Enterprise Universe**

| Information | Link |
|------------|------|
| **Initiator** | [Raymond Demitrio Tel](https://orcid.org/0009-0003-1328-2430) |
| **ORCID** | [0009-0003-1328-2430](https://orcid.org/0009-0003-1328-2430) |
| **Website** | [tel1.nl](https://tel1.nl) |
| **WhatsApp** | [+31 613 803 782](https://wa.me/31613803782) |
| **GitHub** | [myopenai/togethersystems](https://github.com/myopenai/togethersystems) |
| **Businessplan** | [TGPA Businessplan DE.pdf](https://github.com/T-T-T-Sysytems-T-T-T-Systems-com-T-T/.github/blob/main/TGPA_Businessplan_DE.pdf) |

**Branding:** T,.&T,,.&T,,,.(C)(R)TEL1.NL - TTT,. -

**IBM+++ MCP MCP MCP Standard** | **Industrial Business Machine** | **Industrial Fabrication Software**

---
